package com.skm.sso.config;

public class StringConst {

	public static final String SEEDKEY = "SKMAGICSSOV00001";
}
