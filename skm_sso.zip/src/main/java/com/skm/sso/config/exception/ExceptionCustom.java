package com.skm.sso.config.exception;

public class ExceptionCustom extends RuntimeException{
	private static final long serialVersionUID = 1L;
	private final String ERR_CODE;
    
    public ExceptionCustom(String errCode){
        super(getMsg(errCode) + " errCode : [" + errCode + "]");
        this.ERR_CODE = errCode;
    }

    public String getErrCode(){
        return this.ERR_CODE;
    }
    
    private static String getMsg(String errCode) {
    	String msg = "";
    	switch(errCode) {
	        case "P0001": msg = ExceptionConst.P0001;
	             break;
	        case "M0001": msg = ExceptionConst.M0001;
	        	break;
	        case "M0002": msg = ExceptionConst.M0002;
        	break;
	        case "M0003": msg = ExceptionConst.M0003;
        	break;
	        case "S0001": msg = ExceptionConst.S0001;
        		break;
	        case "D0001": msg = ExceptionConst.D0001;
        		break;
	        default: msg = ExceptionConst.DEFAULT;
	             break;
	    }
    	return msg;
    }
}


