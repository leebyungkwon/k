package com.skm.sso.site.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.skm.sso.config.exception.ExceptionCustom;
import com.skm.sso.site.domain.SiteDomain;
import com.skm.sso.site.repository.SiteRepository;

@Service
public class SiteService {

}