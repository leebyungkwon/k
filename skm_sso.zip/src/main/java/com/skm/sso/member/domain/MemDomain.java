package com.skm.sso.member.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;

@Data
@Entity(name="member")
public class MemDomain {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mno;

	private String mid;
	private String memNm;
	private String birth;
	private String phone;
	private String ci;
	private String di;
	private String safeKey;
	private String token;

    @CreationTimestamp
	private LocalDateTime regDt;
	
	private LocalDateTime tokenRegDt;
	
    
}
