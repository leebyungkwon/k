package com.skm.sso.member.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.skm.sso.member.domain.SiteDomain;

@Repository
public interface SiteRepository extends CrudRepository<SiteDomain, Long> {
	
	public SiteDomain findBySid(String sid);
}
