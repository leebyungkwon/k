package com.skm.sso.member.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skm.sso.config.enc.SsoUtil;
import com.skm.sso.member.domain.MemDomain;
import com.skm.sso.member.service.MemService;

@RestController
@RequestMapping("/mem")
public class MemController {
	
	@Autowired private MemService memService;
	
	/**
	 * 고객정보 조회
	 * @param mem
	 * @return
	 */
	@GetMapping(value="/get")
	public ResponseEntity<MemDomain> getMem(MemDomain mem){
		System.out.println("##### getMem");
		System.out.println(mem);
		Optional<MemDomain> m = memService.findByMno(mem.getMid());
		return new ResponseEntity<MemDomain>(m.get(), HttpStatus.OK);
	}
	
	/**
	 * 고객정보 저장
	 * @param mem
	 * @param sid
	 * @return
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@PostMapping(value="/save")
	public ResponseEntity<MemDomain> save(MemDomain mem, String sid) throws IllegalArgumentException, IllegalAccessException{

		mem.setBirth(SsoUtil.seedDecrypt(mem.getBirth()));
		mem.setCi(SsoUtil.seedDecrypt(mem.getCi()));
		mem.setDi(SsoUtil.seedDecrypt(mem.getDi()));
		mem.setMemNm(SsoUtil.seedDecrypt(mem.getMemNm()));
		mem.setMid(SsoUtil.seedDecrypt(mem.getMid()));
		mem.setPhone(SsoUtil.seedDecrypt(mem.getPhone()));
		mem.setSafeKey(SsoUtil.seedDecrypt(mem.getSafeKey()));
		sid = SsoUtil.seedDecrypt(sid);

		System.out.println("##################");
		System.out.println(mem);
		System.out.println(sid);
		return new ResponseEntity<MemDomain>(memService.save(mem, sid), HttpStatus.OK);
	}
	

}