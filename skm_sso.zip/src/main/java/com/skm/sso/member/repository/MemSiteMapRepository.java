package com.skm.sso.member.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.skm.sso.member.domain.MemSiteMapDomain;
import com.skm.sso.member.domain.MemSiteMapKey;

@Repository
public interface MemSiteMapRepository extends CrudRepository<MemSiteMapDomain, MemSiteMapKey> {
	public MemSiteMapDomain save(MemSiteMapDomain mem);
	public MemSiteMapDomain findByMemSiteMapKeyCiAndMemSiteMapKeyDiAndMemSiteMapKeySid(String ci, String di, String sid);
}
