package com.skm.sso.member.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skm.sso.config.exception.ExceptionCustom;
import com.skm.sso.member.domain.MemDomain;
import com.skm.sso.member.domain.MemSiteMapDomain;
import com.skm.sso.member.domain.MemSiteMapKey;
import com.skm.sso.member.repository.MemRepository;
import com.skm.sso.member.repository.MemSiteMapRepository;

@Service
public class MemService {

	@Autowired private MemRepository memRepo;
	@Autowired private MemSiteMapRepository memSiteMapRepo;
	
	public Optional<MemDomain> findByMno(String mid) {
		return memRepo.findByMno(mid); 
	}

	@Transactional
	public MemDomain save(MemDomain mem, String sid){
		
		if(sid == null || mem.getCi() == null || mem.getDi() == null || mem.getMid() == null) throw new ExceptionCustom("P0001");

		/* 2. 유효한 사용자 체크 */
		MemSiteMapDomain exMapDomain = memSiteMapRepo.findByMemSiteMapKeyCiAndMemSiteMapKeyDiAndMemSiteMapKeySid(
				mem.getCi(), mem.getDi(), sid);
		if(exMapDomain != null) throw new ExceptionCustom("D0001");
		
		MemSiteMapKey memSiteMapKey = new MemSiteMapKey();
		memSiteMapKey.setCi(mem.getCi());
		memSiteMapKey.setDi(mem.getDi());
		memSiteMapKey.setSid(sid);
		MemSiteMapDomain mapDomain = new MemSiteMapDomain();
		mapDomain.setMemSiteMapKey(memSiteMapKey);
		
		memSiteMapRepo.save(mapDomain);
		return memRepo.save(mem); 
	}
	
	public int saveNullToken(String ci, String di) {
		return memRepo.saveNullToken(ci, di); 
	}

}
