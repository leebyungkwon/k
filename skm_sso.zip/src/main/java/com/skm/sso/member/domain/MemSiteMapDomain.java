package com.skm.sso.member.domain;

import java.time.LocalDateTime;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Embeddable
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Entity(name="member_site_map")
public class MemSiteMapDomain {
	@EmbeddedId
    protected MemSiteMapKey memSiteMapKey;

    @CreationTimestamp
    private LocalDateTime regDt;
    @UpdateTimestamp
    private LocalDateTime uptDt;
    
}


