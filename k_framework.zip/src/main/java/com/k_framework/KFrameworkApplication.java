package com.k_framework;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@EnableCaching()
@SpringBootApplication
@MapperScan("com.k_framework.*.*.repository")
public class KFrameworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(KFrameworkApplication.class, args);
	}
}
