package com.k_framework.entity;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;

@Data
@Entity(name="tbl_version")
@DynamicUpdate
public class VersionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)  
	private Long verId;
	
	private String versionNm;
	private Long versionNum;

    @Column(updatable=false)
    @CreationTimestamp
	private LocalDateTime regDt;
    
	
}