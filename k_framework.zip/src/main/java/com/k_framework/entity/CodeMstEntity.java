package com.k_framework.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.k_framework.bo.member.entity.MemberRoleEntity;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Getter
@Table(name = "tbl_code_mst")
public class CodeMstEntity extends BaseEntity{

    @Id
    @Column(length = 10, nullable = false)
    private String codeMstCd;
    
    @Column(length = 100, nullable = true)
    private String codeMstNm;

    @Column(length = 100, nullable = true)
    private String codeMstDesc;

    @Column(length = 100, nullable = true)
    private String property01;

    @Column(length = 100, nullable = true)
    private String property02;

    @Column(length = 100, nullable = true)
    private String property03;

    @Column(length = 100, nullable = true)
    private String property04;

    @Column(length = 100, nullable = true)
    private String property05;

    @OneToMany(mappedBy = "codeMstCd", fetch = FetchType.EAGER)
    List<CodeDtlEntity> codeDtl;
    
    @Builder
    public CodeMstEntity(String codeMstCd, String codeMstNm, String codeMstDesc
    		, String property01, String property02, String property03, String property04, String property05) {
        this.codeMstCd = codeMstCd;
        this.codeMstNm = codeMstNm;
        this.codeMstDesc = codeMstDesc;
        this.property01 = property01;
        this.property02 = property02;
        this.property03 = property03;
        this.property04 = property04;
        this.property05 = property05;
    }
}
