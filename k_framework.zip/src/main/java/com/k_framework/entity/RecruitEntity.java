package com.k_framework.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Getter
@Table(name = "tbl_recruiter")
public class RecruitEntity extends BaseEntity{

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long recrNo;

    @Column(length = 100, nullable = true)
    private String recrNm;

    @Column(length = 100, nullable = true)
    private String recrEmail;

    @Column(length = 20, nullable = true)
    private String recrMobile;

    @Column(length = 10, nullable = true)
    private String recrType;
    
    @Column(length = 2, nullable = false)
    @ColumnDefault("'01'") 
    private String recrStep;

    private Long attchNo1;
    
    private Long attchNo2;
    
    private Long attchNo3;
    
    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
    private LocalDateTime recrRegDt;
    
    @Builder
    public RecruitEntity(Long recrNo, String recrNm, String recrEmail, String recrMobile, String recrType, String recrStep) {
        this.recrNo = recrNo;
        this.recrNm = recrNm;
        this.recrEmail = recrEmail;
        this.recrMobile = recrMobile;
        this.recrType = recrType;
        this.recrStep = recrStep;
    }
}
