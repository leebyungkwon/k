package com.k_framework.config.exception;

public class ExceptionConst {

	public static final String DEFAULT = "An error has occurred..";
	
	public static final String A0001 = "success";
	
	public static final String P0001 = "Please check the required variable..";
	public static final String P0002 = "Please check the [type] variable..";
	public static final String P0003 = "Please check the [SITE_ID and secretKey] variable..";
	public static final String P0004 = "Please check the [ci or safeKey] variable..";
	
	public static final String M0001 = "User does not exist..";
	public static final String M0002 = "This user is not registered on the target site..";
	
	public static final String S0001 = "Please check the Site or the SecretKey variable..";
	public static final String S0002 = "Site/SecretKey is not registered..";
	public static final String S0003 = "Token is not valid..";
	public static final String S0004 = "The token does not exist..";
	
	public static final String D0001 = "USER/SITE already exists..";
	public static final String D0002 = "No data..";
	public static final String D0003 = "SITE is not linked..";
}