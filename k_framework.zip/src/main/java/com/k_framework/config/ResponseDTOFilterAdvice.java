package com.k_framework.config;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.k_framework.common.common.service.CommonService;
import com.k_framework.config.message.ResponseMsg;

import lombok.extern.log4j.Log4j2;

@Log4j2
/*@ControllerAdvice*/
public class ResponseDTOFilterAdvice implements ResponseBodyAdvice<Object> {

	@Autowired private CommonService commonService;
	
    @Override
    public boolean supports(final MethodParameter returnType, final Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(final Object body, final MethodParameter returnType, final MediaType selectedContentType,
    								final Class<? extends HttpMessageConverter<?>> selectedConverterType, final ServerHttpRequest request,
    								final ServerHttpResponse response) {
    	
    	log.info("#### ResponseDTOFilterAdvice beforeBodyWrite");
    	log.info(body);
    	log.info("#### end");
    		//commonService.logSave((ResponseMsg) body);
        return body;
    }
    
 
    @ExceptionHandler(value = Exception.class)
    public ResponseEntity handleException(HttpServletRequest request, Exception e) {    	
    	log.info("#### ResponseDTOFilterAdvice handleException");
        log.info(String.valueOf(request.getRequestURL()));
        return new ResponseEntity<>("GlobalExceptionHandler.handleException" + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}