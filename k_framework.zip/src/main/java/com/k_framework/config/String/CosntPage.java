package com.k_framework.config.String;

public class CosntPage {
	public static String Common = "/common";
	public static String Error = "/error";

	public static String BoTempletePage = "bo/templete"; 
	
	public static String BoMainPage = "bo/"; 
	public static String BoMemPage = "bo/mem"; 
	public static String BoBoardPage = "bo/board"; 
	public static String BoManagePage = "bo/manage"; 
	public static String BoRecruitPage = "bo/recruit"; 
}
