package com.k_framework.config;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.k_framework.common.common.service.CommonService;
import com.k_framework.config.message.ResponseMsg;
import com.k_framework.entity.LogEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ConfigurationForInterceptor extends HandlerInterceptorAdapter {
	
	@Autowired private CommonService commonService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

		String sid = request.getHeader("site");
		String secretKey = request.getHeader("SecretKey");
		String ip = request.getRemoteAddr();
		String url = request.getRequestURI();
		

		log.info("============================== START ==============================");
		log.info(" Class       \t:  "	+ handler.getClass());
		log.info(" Request URI \t:  "	+ url);
		log.info(" ip \t:  " 			+ ip);
		
		String ips = request.getHeader("X-Forwarded-For");
		 

		if("/".equals(url) || "/error".equals(url)) return false;

		Enumeration<String> paramNames = request.getParameterNames();
		String p = "?";
    	
		while (paramNames.hasMoreElements()) {
			String key = (String) paramNames.nextElement();  
			String value = request.getParameter(key);

			value = value.trim();
	    	
    		if(!"?".equals(p)) p = p + "&";
    		
    		p = p + key + "="+value;

		}

		log.info(" param \t:  " 		+ p);
		
		LogEntity logDomain = new LogEntity();
		logDomain.setSiteId(sid);
		logDomain.setSecretKey(secretKey);
		logDomain.setIp(ip);
		logDomain.setParam(p);
		logDomain.setUrl(request.getRequestURI());
		
		LogEntity l = commonService.logSave(logDomain);
		request.setAttribute("lid", l.getLogId());
		return super.preHandle(request, response, handler);
	}
	

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response,Object obj, ModelAndView mav)	throws Exception {
	}
	
}