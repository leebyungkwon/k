package com.k_framework.config;

public class ConfigurationForMybatis {

}
