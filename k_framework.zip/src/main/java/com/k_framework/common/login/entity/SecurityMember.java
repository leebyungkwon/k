package com.k_framework.common.login.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.k_framework.bo.member.entity.MemberEntity;
import com.k_framework.bo.member.entity.MemberRoleEntity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecurityMember extends User {
	private static final String ROLE_PREFIX = "ROLE_";
	private static final long serialVersionUID = 1L;
	
	public SecurityMember(MemberEntity member) { 
		super(member.getMemberNo().toString(), member.getPassword(), makeGrantedAuthority(member.getRoles()));
	}
	private static List<GrantedAuthority> makeGrantedAuthority(List<MemberRoleEntity> roles){
		List<GrantedAuthority> list = new ArrayList<>();
		roles.forEach(role -> list.add(new SimpleGrantedAuthority(ROLE_PREFIX + role.getRoleName())));
		return list;
	}
	
}