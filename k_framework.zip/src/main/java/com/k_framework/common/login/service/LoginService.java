package com.k_framework.common.login.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.k_framework.bo.member.entity.MemberEntity;
import com.k_framework.bo.member.entity.MemberRoleEntity;
import com.k_framework.bo.member.repository.MemberRepository;
import com.k_framework.bo.member.repository.MemberRoleRepository;
import com.k_framework.common.login.entity.SecurityMember;

@Service
public class LoginService implements UserDetailsService {
    
	@Autowired private MemberRepository memberRepository;
	@Autowired private MemberRoleRepository memberRoleRepository;
    
    MemberEntity member;
    @Transactional
    public Long saveUser(MemberEntity memberEntity) {
        // 비밀번호 암호화
    	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    	memberEntity.setPassword(passwordEncoder.encode(memberEntity.getPassword()));

        return memberRepository.save(memberEntity).getMemberNo();
    }

    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		return 
			Optional.ofNullable(memberRepository.findByEmail(email))
			.filter(member -> member!= null)
			.map(member -> new SecurityMember((MemberEntity) member)).get();
	}

	public void saveRole(MemberRoleEntity role) {
		role.setRoleName("MEMBER");
		memberRoleRepository.save(role);
	}

}