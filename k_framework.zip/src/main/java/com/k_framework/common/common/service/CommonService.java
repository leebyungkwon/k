package com.k_framework.common.common.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.k_framework.common.common.repository.CodeRepository;
import com.k_framework.common.common.repository.LogRepository;
import com.k_framework.common.common.repository.VersionRepository;
import com.k_framework.config.message.ResponseMsg;
import com.k_framework.entity.CodeDtlEntity;
import com.k_framework.entity.CodeMstEntity;
import com.k_framework.entity.LogEntity;
import com.k_framework.entity.VersionEntity;

@Service
public class CommonService {

	@Autowired private LogRepository logRepo;
	@Autowired private VersionRepository verRepo;
	@Autowired private CodeRepository codeRepo;
	
	public LogEntity logSave(LogEntity logDomain) {
		return logRepo.save(logDomain);
	}
	
	public LogEntity logSave(ResponseMsg responseMsg) {
		LogEntity logDomain = new LogEntity();
		logDomain.setLogId(responseMsg.getLogId());
		logDomain.setMessage(responseMsg.getMessage());
		logDomain.setCode(responseMsg.getCode());
		logDomain.setStatus(responseMsg.getStatus());
		LocalDateTime completeDt = LocalDateTime.now(); 
		logDomain.setCompleteDt(completeDt);
		if(null != responseMsg.getData() )logDomain.setResult(responseMsg.getData().toString());
		return logRepo.save(logDomain);
	}
	
	@CacheEvict(value = "static", allEntries=true)
	public VersionEntity verSave(VersionEntity versionDomain) {
		return verRepo.save(versionDomain);
	}
	
	@Cacheable(value = "static")
	public Optional<VersionEntity> getVer(VersionEntity versionDomain) {
		return verRepo.findById(versionDomain.getVerId());
	}

	public Object selectCommonCodeList(CodeMstEntity code) {
		CodeMstEntity codeMst = codeRepo.findByCodeMstCd(code.getCodeMstCd());
		List<CodeDtlEntity> codeDet = null;
		if(codeMst != null) {
			codeDet = codeMst.getCodeDtl();
		}
		return codeDet;
	}

}