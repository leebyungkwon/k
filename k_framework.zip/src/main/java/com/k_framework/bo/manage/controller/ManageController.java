package com.k_framework.bo.manage.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.k_framework.bo.manage.entity.ExcelMstEntity;
import com.k_framework.bo.manage.service.ManageService;
import com.k_framework.config.String.CosntPage;
import com.k_framework.config.message.ResponseMsg;


@RestController
@RequestMapping(value="/bo/manage")
public class ManageController {
	
	@Autowired private ManageService manageService;
	
	@GetMapping(value="/excel")
	public ModelAndView excelPage() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoManagePage+"/excel");
        return mv;
	}
	
	@PostMapping(value="/excelList")
	public ResponseEntity<ResponseMsg> excelList(ExcelMstEntity excel, Pageable pageable){
		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,null );
    	responseMsg.setData(manageService.findAll(excel, pageable));
		return new ResponseEntity<ResponseMsg>(responseMsg ,HttpStatus.OK);
	}
	
	@PostMapping("/p/excelSave")
    public ModelAndView excelSavePop() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoManagePage+"/p/popExcelSave");
        return mv;
    }
	
}
