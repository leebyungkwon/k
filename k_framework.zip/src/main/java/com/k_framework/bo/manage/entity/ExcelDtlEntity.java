package com.k_framework.bo.manage.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.ibatis.type.Alias;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Data
@Entity
@Alias("excelDtl")
@Table(name = "tbl_excel_dtl")
public class ExcelDtlEntity{
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long excelDtlId;
    
    private Long columnNo;

    @Column(length =10, nullable = true)
    private String columnRow;
    
    @Column(length =200, nullable = true)
    private String columnNm;

    @Column(length = 200, nullable = true)
    private String columnDesc;
    
    @Column(length = 100, nullable = true)
    private String columnType;
    
    private Integer columnLenMin;
    
    private Integer columnLenMax;

    @Column(length = 200, nullable = true)
    private String columnEnum;

    @Column(length = 1, nullable = false)
    @ColumnDefault("'Y'") 
    private String useYn;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime regDate;
    
    @UpdateTimestamp
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime updDate;


    @ManyToOne
    @JoinColumn(name = "excelMstId")
    @JsonIgnore
    ExcelMstEntity excelMstId;
}