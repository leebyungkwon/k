package com.k_framework.bo.manage.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.k_framework.bo.manage.entity.ExcelMstEntity;
import com.k_framework.bo.manage.repository.ExcelRepository;

@Service
public class ManageService {

	@Autowired
	private ExcelRepository manageRepository;
	
	public HashMap<String, Object> findAll(ExcelMstEntity excel, Pageable pageable) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		Page<ExcelMstEntity> p = manageRepository.findAll(pageable);
		result.put("list", p.getContent());
		result.put("pageCnt", p.getTotalPages());
		return result;
	}

}
