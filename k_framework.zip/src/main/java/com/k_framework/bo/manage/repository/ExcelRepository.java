package com.k_framework.bo.manage.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.k_framework.bo.manage.entity.ExcelMstEntity;

public interface ExcelRepository extends JpaRepository<ExcelMstEntity, Long>{

}
