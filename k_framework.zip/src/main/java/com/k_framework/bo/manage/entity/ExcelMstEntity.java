package com.k_framework.bo.manage.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.ibatis.type.Alias;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.k_framework.common.common.domain.PagingDomain;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Alias("excelMst")
@Table(name = "tbl_excel_mst")
public class ExcelMstEntity extends PagingDomain{
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long excelMstId;
    
    @Column(length =100, nullable = false)
    private String excelTitle;

    @Column(length = 200, nullable = true)
    private String excelDesc;
    
    @Column(length = 100, nullable = true)
    private String docNm;

    @Column(length = 1, nullable = false)
    @ColumnDefault("'Y'") 
    private String useYn;

    @OneToMany(mappedBy = "excelMstId", fetch = FetchType.EAGER)
    List<ExcelDtlEntity> excelDtl;
    
    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime regDate;
    
    @UpdateTimestamp
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime updDate;


}