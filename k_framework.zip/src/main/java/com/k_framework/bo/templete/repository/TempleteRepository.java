package com.k_framework.bo.templete.repository;

import java.util.List;

import com.k_framework.bo.board.domain.BoardDomain;

public interface TempleteRepository  {
	List<BoardDomain> selectTemplete(BoardDomain entity);
}
