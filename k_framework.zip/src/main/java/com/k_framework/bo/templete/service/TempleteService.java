package com.k_framework.bo.templete.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.k_framework.bo.board.domain.BoardDomain;
import com.k_framework.bo.templete.repository.TempleteJpaRepository;
import com.k_framework.bo.templete.repository.TempleteRepository;
import com.k_framework.config.message.ResponseMsg;
import com.k_framework.entity.BoardEntity;

@Service
public class TempleteService {

	@Autowired
	private TempleteJpaRepository templeteJpaRepository;
	@Autowired
	private TempleteRepository templeteRepository;

	@Transactional
	public ResponseMsg templeteSave(BoardEntity board) {
		System.out.println("### templeteSave :: "+board);
		BoardEntity b = templeteJpaRepository.save(board);
		if (b == null)
			return new ResponseMsg(HttpStatus.BAD_GATEWAY, "COM0002");
		return new ResponseMsg(HttpStatus.OK, "COM0001", b, "저장</br>되었습니다.");
	}

	@Transactional(readOnly=true)
	public HashMap<String, Object> findAll(BoardEntity board, Pageable pageable) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		//Page<BoardEntity> p = templeteRepository.findAll(pageable);

		Page<BoardEntity> p = templeteJpaRepository.findByBoardTitleIgnoreCaseStartsWith(board.getBoardTitle(), pageable);
		result.put("list", p.getContent());
		result.put("pageCnt", p.getTotalPages());
		return result;
	}
	
	@Transactional(readOnly=true)
	public Optional<BoardEntity> findById(BoardEntity board) {
		return templeteJpaRepository.findById(board.getBoardNo());
	}

	@Transactional
	public HashMap<String, Object> selectTemplete(BoardDomain board) {
		System.out.println("### selectTemplete :: " + board + board.getIsPaging());
		List<BoardDomain> p = templeteRepository.selectTemplete(board);
		int pageCnt = (p.size()>0) ? (int) Math.ceil((double) p.get(0).getTotalPages() / (double) p.get(0).getSize()) : 0; 
		HashMap<String, Object> result = new HashMap<String, Object>();
		result.put("list", p);
		result.put("pageCnt", pageCnt);
		return result;
	}

}
