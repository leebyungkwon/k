package com.k_framework.bo.recruit.controller;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.k_framework.bo.recruit.domain.RecruitDomain;
import com.k_framework.bo.recruit.service.RecruitService;
import com.k_framework.config.String.CosntPage;
import com.k_framework.config.message.ResponseMsg;
import com.k_framework.entity.FileEntity;
import com.k_framework.entity.RecruitEntity;
import com.k_framework.util.UtilExcel;
import com.k_framework.util.UtilFile;

@RestController
@RequestMapping(value="/bo/recruit")
public class RecruitController {

	@Autowired private RecruitService recruitService;
	
	@Autowired UtilFile utilFile;
	
	@GetMapping(value="/list")
	public ModelAndView recruitList() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoRecruitPage+"/recruitList");
        return mv;
	}
	@GetMapping(value="/regList")
	public ModelAndView recruitRegList() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoRecruitPage+"/recruitRegList");
        return mv;
	}
	@PostMapping(value="/list")
	public ResponseEntity<ResponseMsg> recruitDataList(RecruitDomain recruit, Pageable pageable){
		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,null );
    	responseMsg.setData(recruitService.findAll(recruit, pageable));
		return new ResponseEntity<ResponseMsg>(responseMsg ,HttpStatus.OK);
	}
	
	@PostMapping("/excel")
	public ResponseEntity<ResponseMsg> uploadExcel(@RequestParam("files") MultipartFile[] files, Model model) throws IOException { 

		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,null );

		Map<String, Object> ret = utilFile.setPath("test")
				.setFiles(files)
				.setExt("excel")
				.upload();
		System.out.println("## file");
		System.out.println(ret);
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(); 
		if((boolean) ret.get("success")) {
			List<FileEntity> file = (List<FileEntity>) ret.get("data");
			System.out.println(file);
			if(file.size()>0) {
				String path = Paths.get(file.get(0).getFilePath(), file.get(0).getFileSaveNm()+"."+file.get(0).getFileExt()).toString();
				result = new UtilExcel().upload(path);
		    	responseMsg.setData(recruitService.save(result));
			}
		}
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
	@PostMapping("/save")
	public ResponseEntity<ResponseMsg> recruitSave(RecruitEntity recruit) {
		ResponseMsg responseMsg = recruitService.save(recruit);
		
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
}
