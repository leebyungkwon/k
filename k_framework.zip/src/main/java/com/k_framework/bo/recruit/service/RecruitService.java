package com.k_framework.bo.recruit.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.k_framework.bo.manage.entity.ExcelDtlEntity;
import com.k_framework.bo.manage.entity.ExcelMstEntity;
import com.k_framework.bo.manage.repository.ExcelRepository;
import com.k_framework.bo.recruit.domain.RecruitDomain;
import com.k_framework.bo.recruit.repository.RecruitJpaRepository;
import com.k_framework.bo.recruit.repository.RecruitRepository;
import com.k_framework.config.message.ResponseMsg;
import com.k_framework.entity.RecruitEntity;
import com.k_framework.util.UtilString;

@Service
public class RecruitService {
	
	@Autowired RecruitRepository recruitRepository;
	@Autowired RecruitJpaRepository recruitJpaRepository;
	@Autowired ExcelRepository excelRepository;
	
	public HashMap<String, Object> findAll(RecruitDomain recruit, Pageable pageable) {
		
		List<RecruitDomain> p = recruitRepository.selectRecruit(recruit);
		int pageCnt = (p.size()>0) ? (int) Math.ceil((double) p.get(0).getTotalPages() / (double) pageable.getPageSize()) : 0; 
		HashMap<String, Object> result = new HashMap<String, Object>();
		result.put("list", p);
		result.put("pageCnt", pageCnt);
		
		Optional<ExcelMstEntity> excel = excelRepository.findById(1L);
		for(RecruitDomain r : p) {
			String error = "";
			for(ExcelDtlEntity dtl : excel.get().getExcelDtl()){
				if(dtl.getColumnRow().equals("C")) {
					if(r.getRecrEmail().length()>dtl.getColumnLenMax()) error = error + "["+ dtl.getColumnNm() + "] 데이터 길이가 길다[현재:"+r.getRecrEmail().length()+",최대:"+dtl.getColumnLenMax()+"]";
					if(UtilString.isStr(r.getRecrEmail())) error = error + "["+ dtl.getColumnNm() + "] 필수 값임";
				}
				if(dtl.getColumnRow().equals("E")) {
					if(!dtl.getColumnEnum().contains(r.getRecrType())) {
						error = error + "["+ dtl.getColumnNm() + "] 코드가 잘못 등록 (필요코드:"+dtl.getColumnEnum()+")";
						//error = error + "</br>에러";
					}
				}
			}
			r.setError(error);
		}
		return result;
	}

	@Transactional
	public Object save(List<Map<String, Object>> result) {
		//return new ResponseMsg(HttpStatus.BAD_REQUEST ,"S0003");
		for(Map<String, Object> m : result){
			String recrNm = UtilString.setStr((m.get("A")==null)?"":m.get("A").toString());
			String recrEmail = UtilString.setStr((m.get("B")==null)?"":m.get("B").toString());
			String recrMobile = UtilString.setStr(UtilString.setStr((m.get("C")==null)?"":m.get("C").toString())).replaceAll("-", "");
			String recrType = UtilString.setStr((m.get("D")==null)?"":m.get("D").toString());
			
			RecruitEntity recr = RecruitEntity.builder()
					   .recrNm(recrNm)
					   .recrEmail(recrEmail)
					   .recrMobile(recrMobile)
					   .recrType(recrType)
					   .recrStep("01")
					   .build();
								   
			recruitJpaRepository.save(recr);
		}
		
		return new ResponseMsg(HttpStatus.OK ,"A0001", "");
	}

	@Transactional
	public ResponseMsg save(RecruitEntity recruit) {
		RecruitEntity result = recruitJpaRepository.save(recruit);
		if (result == null)
			return new ResponseMsg(HttpStatus.BAD_GATEWAY, "COM0002");
		return new ResponseMsg(HttpStatus.OK, "COM0001", result);
	}
	
	
}
