package com.k_framework.bo.recruit.domain;

import java.time.LocalDateTime;

import org.apache.ibatis.type.Alias;

import com.k_framework.common.common.domain.PagingDomain;

import lombok.Data;

@Data
@Alias("recruit")
public class RecruitDomain extends PagingDomain{

    private Long recrNo;

    private String recrNm;

    private String recrEmail;

    private String recrMobile;

    private String recrType;
    
    private String recrStep;

    private LocalDateTime recrRegDt;
    
    private String error;
  
}
