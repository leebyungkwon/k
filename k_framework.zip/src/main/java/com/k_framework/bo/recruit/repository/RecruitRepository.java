package com.k_framework.bo.recruit.repository;

import java.util.List;

import com.k_framework.bo.recruit.domain.RecruitDomain;

public interface RecruitRepository  {
	List<RecruitDomain> selectRecruit(RecruitDomain recruit);
}
