package com.k_framework.bo.recruit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.k_framework.entity.RecruitEntity;

public interface RecruitJpaRepository extends JpaRepository<RecruitEntity, Long>{

}
