package com.k_framework.bo.board.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.k_framework.entity.BoardEntity;

public interface BoardRepository extends JpaRepository<BoardEntity, Long> {

}
