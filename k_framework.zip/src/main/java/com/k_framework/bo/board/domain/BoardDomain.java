package com.k_framework.bo.board.domain;


import org.apache.ibatis.type.Alias;
import com.k_framework.common.common.domain.BaseDomain;
import lombok.Data;

@Data
@Alias("board")
public class BoardDomain extends BaseDomain{
	
    private Long boardNo;
    private String boardType;
    private String boardTitle;
    private String boardCnts;

}