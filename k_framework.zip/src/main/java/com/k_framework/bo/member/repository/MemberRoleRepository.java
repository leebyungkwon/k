package com.k_framework.bo.member.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.k_framework.bo.member.entity.MemberEntity;
import com.k_framework.bo.member.entity.MemberRoleEntity;

public interface MemberRoleRepository extends JpaRepository<MemberRoleEntity, Long> {

}