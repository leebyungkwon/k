package com.k_framework.bo.member.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.k_framework.bo.member.entity.MemberEntity;
import com.k_framework.bo.member.service.MemberService;
import com.k_framework.config.String.CosntPage;
import com.k_framework.config.message.ResponseMsg;

@Controller
@RequestMapping(value="/bo/mem")
public class MemberController {
	
	@Autowired MemberService memberService;
	
	@GetMapping(value="")
	public ModelAndView memList() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoMemPage+"/memList");
        return mv;
	}
	
	@PostMapping(value="/list")
	public ResponseEntity<ResponseMsg> list(HttpServletRequest request, MemberEntity mem){
		Long logId = (Long) request.getAttribute("lid");

		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,"A0001" );
		responseMsg.setLogId(logId);
    	HashMap<String, Object> result = new HashMap<String, Object>();
    	List<MemberEntity> memList = memberService.findAll(PageRequest.of(0, 2, Sort.Direction.DESC, "id" ));
    	result.put("list", memList);
    	responseMsg.setData(result);
    	responseMsg.setLogId(logId);
		return new ResponseEntity<ResponseMsg>(responseMsg ,HttpStatus.OK);
	}
}
