package com.k_framework.bo.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.k_framework.bo.member.entity.MemberEntity;
import com.k_framework.bo.member.repository.MemberRepository;

@Service
public class MemberService {
    
	@Autowired private MemberRepository memberRepository;

	public List<MemberEntity> findAll(PageRequest pageable) {
		Page<MemberEntity> p = memberRepository.findAll(pageable);
		return p.getContent();
	}
    
}