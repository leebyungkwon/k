package com.k_framework.bo.member;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.k_framework.bo.member.entity.MemberEntity;
import com.k_framework.bo.member.entity.MemberRoleEntity;

public class CustomSecurityUser extends User {

    private static final String ROLE_PREFIX = "ROLE_";

    private MemberEntity member;
    public CustomSecurityUser(MemberEntity member) {
        //super(member.getEmail(), "{noop}" + member.getPassword(), makeGrantedeAuth(member.getRoles()));
        this.member = member;
    }

    private static List<GrantedAuthority> makeGrantedeAuth(List<MemberRoleEntity> roles) {
        List<GrantedAuthority> list = new ArrayList<>();
        roles.forEach(memberRole -> 
            list.add(new SimpleGrantedAuthority(ROLE_PREFIX + memberRole.getRoleName())));
        return list;
    }
}