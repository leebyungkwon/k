package com.k_framework.bo.member.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.k_framework.bo.member.entity.MemberEntity;


public interface MemberRepository extends JpaRepository<MemberEntity, Long> {
	MemberEntity findByEmail(String email);
}