package com.k_framework.bo.member.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.k_framework.common.common.domain.BaseDomain;

import lombok.Data;

@Data
@Entity
@Table(name = "tbl_member_role")
public class MemberRoleEntity extends BaseDomain{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roleNo;

    private String roleName;
    
    @ManyToOne
    @JoinColumn(name = "memberNo")
    @JsonIgnore
    MemberEntity memberNo;

}
