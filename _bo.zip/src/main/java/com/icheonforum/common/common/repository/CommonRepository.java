package com.icheonforum.common.common.repository;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.common.common.domain.FileDomain;

@Mapper
public interface CommonRepository {
	void insertFile(FileDomain attach);

}
