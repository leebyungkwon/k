package com.icheonforum.bo.member.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.bo.member.domain.MemberDomain;
import com.icheonforum.bo.member.domain.MemberRoleDomain;

@Mapper
public interface MemberRoleRepository{

	void save(MemberRoleDomain role);
	
	List<MemberRoleDomain> findRoles(MemberDomain memberDomain);

}