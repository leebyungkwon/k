package com.icheonforum.bo.templete.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.bo.board.domain.BoardDomain;

@Mapper
public interface TempleteRepository  {
	List<BoardDomain> selectTemplete(BoardDomain board);
	Long save(BoardDomain board);
	BoardDomain findById(Long boardNo);
	void insert(BoardDomain board);
	void update(BoardDomain board);
}
