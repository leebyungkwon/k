package com.icheonforum.config;

public class ConfigurationForMybatis {

}
