package com.icheonforum.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.icheonforum.common.login.service.LoginService;
import com.icheonforum.config.login.LoginFailurHandler;
import com.icheonforum.config.login.LoginSuccessHandler;

import lombok.AllArgsConstructor;
import lombok.extern.java.Log;

@Log
@Configuration
@EnableWebSecurity
@AllArgsConstructor
public class ConfigurationForSecurity extends WebSecurityConfigurerAdapter {
    
	@Autowired private LoginService loginService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    public void configure(WebSecurity web) throws Exception
    {
        web.ignoring().antMatchers("/static/plugin/**", "/static/css/**", "/static/js/**", "/static/img/**", "/static/lib/**");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

		// ?��?���? 권한 ?��?��
		http.authorizeRequests()
			.antMatchers("/bo/board/**").hasRole("ADMIN")
			.antMatchers("/bo/**").hasAnyRole("ADMIN", "MEMBER")
			// .antMatchers("/bo/mem/boardList").permitAll()
			.antMatchers("/**").permitAll()
			.anyRequest().authenticated();

		// 로그?�� ?��?��
		http.formLogin()
			.loginPage("/login")
			.loginProcessingUrl("/j_spring_security")
			.usernameParameter("email")
			.passwordParameter("password")
			.successHandler(successHandler()).failureUrl("/login").permitAll();

		// 로그?��?�� ?��?��
		http.logout()
			.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
			.logoutSuccessUrl("/login")
			.invalidateHttpSession(true);
		
		// 403 ?��?��처리 ?��?���?
		http.exceptionHandling().accessDeniedPage("/denied");
		
		http.csrf().disable();
    }

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(loginService);
	}
	
	public AuthenticationSuccessHandler successHandler() {
		System.out.println("######### successHandler");
		return new LoginSuccessHandler("/bo/main");
	}
	public AuthenticationFailureHandler failurHandler() {
		System.out.println("######### failurHandler");
		return new LoginFailurHandler();
	}
}