package skmsso.config;

public class LibConst {
	
	public final static String Domain = "http://localhost:8080/";
	public final static String SEEDKEY = "SKMAGICSSOV00001";
	
	public final static String U_ACCESS = "/auth/access";
	public final static String U_GET = "/auth/get";
	public final static String U_OUT = "/auth/out";
	
	
}
