package skmsso.config;

public class LibConst {
	
	public final static String Domain = "http://localhost:8080/";
	public static final String SEEDKEY = "SKMAGICSSOV00001";
}
