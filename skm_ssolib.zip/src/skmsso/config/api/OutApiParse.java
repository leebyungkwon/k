package skmsso.config.api;

import okhttp3.Response;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import java.io.IOException;

public class OutApiParse {

    public static int getCode(Response res){
        int code = res.code();
        return code;
    }

    public static String getData(Response res, String getStr) throws IOException {
        String ret = "";
        switch (getStr) {
            case "Location":
                String r = res.headers().get("Location");
                ret = r.split("/")[r.split("/").length-1];
                break;
            default:
                ret = res.body().string();
                break;
        }
        return ret;
    }
    public static JSONObject getError(Response res) throws IOException, JSONException {
        String resBody = res.body().string();

        JSONObject json = null;
        if(resBody != null && !resBody.isEmpty()) json = new JSONObject(resBody);
        return json;
    }
}
