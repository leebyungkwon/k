package skmsso.util;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Base64.Decoder;

import skmsso.config.LibConst;

public class SEED {
		 
    static String charset = "utf-8";
 
    public static byte pbUserKey[] = new String(LibConst.SEEDKEY).getBytes();
    
 
    public static String encrypt(String str, String secret) throws UnsupportedEncodingException {
    	byte[] bszIV = new String(secret).getBytes();
        byte[] msg = null;
 
        try {
            msg = KISA_SEED_CBC.SEED_CBC_Encrypt(pbUserKey, bszIV, str.getBytes(charset), 0,
                    str.getBytes(charset).length);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
 
        java.util.Base64.Encoder encoder = Base64.getEncoder();
        byte[] encArray = encoder.encode(msg);
        try {
            System.out.println(new String(encArray, "utf-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return new String(encArray, "utf-8");
    }
 
    public static String decrypt(String str, String secret) {
    	byte[] bszIV = new String(secret).getBytes();
        Decoder decoder = Base64.getDecoder();
        byte[] msg = decoder.decode(str);
 
        String result = "";
        byte[] dec = null;
 
        try {
            dec = KISA_SEED_CBC.SEED_CBC_Decrypt(pbUserKey, bszIV, msg, 0, msg.length);
            result = new String(dec, charset);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
 
        System.out.println("decrypt Result = " + result);
        return result;
    }
	 
}
