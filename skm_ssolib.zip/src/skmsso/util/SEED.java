package skmsso.util;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Base64.Decoder;

import skmsso.config.LibConst;

public class SEED {
		 
    static String charset = "utf-8";
 
    public static byte pbUserKey[] = new String(LibConst.SEEDKEY).getBytes();
    
    public static byte bszIV[] = { (byte) 0x22, (byte) 0x25, (byte) 0x28, (byte) 0x5E, 
            (byte) 0x1A, (byte) 0x2A, (byte) 0x25, (byte) 0x21, (byte) 0x21, (byte) 0x42, 
            (byte) 0x45, (byte) 0x78, (byte) 0x41, (byte) 0x55, (byte) 0x4A, (byte) 0x21 };
    
 
    public static String encrypt(String str) throws UnsupportedEncodingException {
        byte[] msg = null;
 
        try {
            msg = KISA_SEED_CBC.SEED_CBC_Encrypt(pbUserKey, bszIV, str.getBytes(charset), 0,
                    str.getBytes(charset).length);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
 
        java.util.Base64.Encoder encoder = Base64.getEncoder();
        byte[] encArray = encoder.encode(msg);
        try {
            System.out.println(new String(encArray, "utf-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return new String(encArray, "utf-8");
    }
 
    public static String decrypt(String str) {
 
        Decoder decoder = Base64.getDecoder();
        byte[] msg = decoder.decode(str);
 
        String result = "";
        byte[] dec = null;
 
        try {
            dec = KISA_SEED_CBC.SEED_CBC_Decrypt(pbUserKey, bszIV, msg, 0, msg.length);
            result = new String(dec, charset);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
 
        System.out.println("decrypt Result = " + result);
        return result;
    }
	 
}
