package skmsso;

import java.io.IOException;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import okhttp3.Response;
import skmsso.execute.OutApiConnector;

public class SsoConnection {
	public static void main(String[] args) throws JSONException, IOException {
		/*
		System.out.println("########## run");
		JSONObject p = new JSONObject();
        p.put("ci", "a");
        p.put("di", "b");
        p.put("sid", "SVC010");
         
		skmsso.execute.OutApiConnector.setApi api = new OutApiConnector.setApi("skcs", "get");
        api.url("/auth/out");
        api.parameterJson(p);
        api.method("GET");
        
        Response res = api.call();
        System.out.println(res.code());
        System.out.println("########### header");
        System.out.println(res.headers());
        System.out.println("########### body");
        System.out.println(res.body().string());
		*/
		JSONObject p = new JSONObject();
        p.put("sid", "SVC010");
        p.put("mid", "testmid11");
        p.put("memNm", "testmemNm11");
        p.put("birth", "testbirth11");
        p.put("phone", "testphone11");
        p.put("di", "testdi11");
        p.put("safeKey", "testsafeKey11");
        

		skmsso.execute.OutApiConnector.setApi api = new OutApiConnector.setApi("skcs", "save");
        api.url("/mem/save");
        api.parameterJson(p);
        api.method("POST");
        
        Response res = api.call();
        System.out.println(res.code());
        System.out.println("########### header");
        System.out.println(res.headers());
        System.out.println("########### body");
        System.out.println(res.body().string());
	}
}
