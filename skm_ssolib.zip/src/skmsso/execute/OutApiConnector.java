package skmsso.execute;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Request.Builder;
import okhttp3.RequestBody;
import okhttp3.Response;
import skmsso.config.LibConst;
import skmsso.util.SEED;

public class OutApiConnector {
    public OutApiConnector() {}
	public static SEED seed = new SEED();
	
    public static class setApi {
        private String receiver;        //api ������
        private String excuteName;      //api ���� ��Ī
        private String url="";          //api url
        private String parameter="";    //api param
        private String token="";        //api ���� ��ū
        private String method="";       //
        private Boolean outLog=false;   //
        private JSONObject parameterJson = new JSONObject();

        public setApi(String receiver, String excuteName) {
            this.receiver   = receiver;
            this.excuteName = excuteName;
        }

        public setApi url(String url){
            this.url = url;
            return this;
        }
        private setApi parameter(String parameter){
            this.parameter = parameter;
            return this;
        }
        public setApi parameterJson(JSONObject parameter){
            this.parameterJson = parameter;
            return this;
        }
        public setApi token(String token){
            this.token = token;
            return this;
        }
        public setApi method(String method){
            this.method = method;
            return this;
        }
        public setApi outLog(Boolean outLog){
            this.outLog = outLog;
            return this;
        }

        public void requestInfo(){
            String str = "";
            str += "\n***************************************************************\n";
            str += "***********OutApiConnector = requestInfo***********\n";
            str += "receiver --> " + receiver + "\n";
            str += "excuteName --> " + excuteName + "\n";
            str += "token --> " + token + "\n";
            str += "method --> " + method + "\n";
            str += "url --> " + url + "\n";
            if("GET".equals(method))    str += "parameter --> " + parameter+  "\n";
            else                        str += "parameter --> " + parameterJson.toString() + "\n";
            //log.info(str);
        }
        public void responseInfo(Response response) throws IOException {
            String str = "";
            str += "\n***************************************************************\n";
            str += "***********OutApiConnector = responseInfo***********\n";
            str += "header --> \n";
            str += response.headers()+"\n";
            str += "code --> \n";
            str += response.code()+"\n";
            str += "message --> \n";
            str += response.message()+"\n";
            //str += "body --> \n";
            //str += res.body().string()+"\n";
            str += "***************************************************************";
            //log.info(str);
        }

        public Response call() throws JSONException, IOException {
            if(outLog) requestInfo();

            Response res = null;
            if(method.equals("GET"))    res = GET(this);
            else                        res = POST(this);

            if(outLog)  responseInfo(res);

            return res;
        }
    }

    private static Response GET(setApi b) throws IOException, JSONException {
    	String p = objectToParam(b.parameterJson);
    	System.out.println("##### GET param :: " + p);
    	
        Builder builder = new Builder()
                                .url(LibConst.Domain+b.url + p)
                                .method(b.method, null);
        return send(builder.build());
    }

    private static Response POST(setApi b) throws IOException, JSONException {
    	String p = objectToParam(b.parameterJson);
    	System.out.println("##### POST param :: " + p);

    	MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");

        Builder builder = new Builder()
                                .url(LibConst.Domain+b.url + p)
                                .method(b.method, body);

        return send(builder.build());
    }
    
    private static String objectToParam(JSONObject parameterJson) throws UnsupportedEncodingException, JSONException {
    	Iterator k = parameterJson.keys();
    	String p = "?";
    	while( k.hasNext() ){
    		if(!"?".equals(p)) p = p + "&";
    		String key =  k.next().toString();
    		String v = URLEncoder.encode(seed.encrypt(parameterJson.getString(key)));
    		p = p + key + "="+v;
    	}
    	return p;
    }
    private static Response send(Request request) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        Response response = client.newCall(request).execute();
        return response;
    }
}
