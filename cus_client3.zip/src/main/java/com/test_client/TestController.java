package com.test_client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import skmssolib.config.api.Conn;
import skmssolib.config.api.Conn.SkmSSO;


@Controller
public class TestController {
	
	@RequestMapping(value="/index")
	public ModelAndView index(String ci, String memNm, String birth, String phone) throws Exception {
		System.out.println("#### index");
		
		ModelAndView mv = new ModelAndView("/index");
		
		Map<String, Object> p1 = new HashMap<String, Object>();
		
        SkmSSO sso1 = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("M_LIST")
				.parameter(p1)
				.method("GET")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso1.getCode());
		System.out.println("--------- ----------- --------" );
		if(sso1.getCode() == 200) {
			System.out.println(sso1.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso1.getStatus();
		
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println("##성공");
		    	List<Map<String, Object>> r =  (List<Map<String, Object>>)  sso1.getData();
	        	mv.addObject("memList", r);
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso1.getCode());
		}
		
		
		Map<String, Object> p2 = new HashMap<String, Object>();
		
        SkmSSO sso2 = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("S_LIST")
				.parameter(p2)
				.method("GET")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso2.getCode());
		System.out.println("--------- ----------- --------" );
		if(sso2.getCode() == 200) {
			System.out.println(sso2.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso2.getStatus();
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println("##성공");
		    	List<Map<String, Object>> r =  (List<Map<String, Object>>)  sso2.getData();
	        	mv.addObject("siteList", r);
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso2.getCode());
		}
		
      
        
        Map<String, Object> p3 = new HashMap<String, Object>();
        p3.put("ci", ci);
        p3.put("memNm", memNm);
        p3.put("birth", birth);
        p3.put("phone", phone);

        SkmSSO sso3 = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("M_GET")
				.parameter(p3)
				.method("GET")
				.call();
        
        if(sso3.getCode() == 200) {
			System.out.println(sso3.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso3.getStatus();
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println("##성공");
		    	List<Map<String, Object>> r =  (List<Map<String, Object>>)  sso3.getData();
		    	mv.addObject("srchList", r);
	        	
	        	Iterator<Entry<String, Object>> entries = r.get(0).entrySet().iterator();
		    	while(entries.hasNext()){
		        	Entry<String,Object> entry = (Entry<String,Object>)entries.next();
		        	System.out.println("key : " + entry.getKey() + " , value : " + entry.getValue());
		    	}
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso3.getCode());
		}
        
        mv.addObject("ci",ci);
        mv.addObject("memNm",memNm);
        mv.addObject("birth",birth);
        mv.addObject("phone",phone);
        mv.addObject("serverNm",StringConst.SITE_ID);
        
		return mv;
	}
	
	@RequestMapping(value="/access", method=RequestMethod.GET)
	public String access(String ci, HttpServletRequest request) throws Exception {
		System.out.println("#### access");
		System.out.println("### CI :: " + ci);

		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", ci);
        
        
        SkmSSO sso = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("A_ACCESS")
				.parameter(p)
				.method("GET")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso.getCode());
		System.out.println("--------- ----------- --------" );
		if(sso.getCode() == 200) {
			System.out.println(sso.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso.getStatus();
		
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println(sso.getToken());
	            HttpSession session = request.getSession();
	            session.setAttribute("token", sso.getToken());
	            session.setAttribute("sci", ci);
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso.getCode());
		}
		return "redirect:index";
	}
	
	@RequestMapping(value="/check", method=RequestMethod.GET)
	public String access(String ci,String siteId,  String token, String returnUrl, HttpServletRequest request) throws Exception {
		System.out.println("#### check");
		System.out.println("### CI :: " + ci);
		System.out.println("### siteId :: " + siteId);

		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", ci);
        p.put("token", token);
        p.put("siteId", siteId);
        
        SkmSSO sso = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("A_CHK")
				.parameter(p)
				.method("GET")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso.getCode());
		System.out.println("--------- ----------- --------" );
		if(sso.getCode() == 200) {
			System.out.println(sso.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso.getStatus();
		
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println(sso.getToken());
	            HttpSession session = request.getSession();
	            session.setAttribute("token", sso.getToken());
	            session.setAttribute("sci", ci);
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso.getCode());
		}
		
		return "redirect:index";
	}
	
	@RequestMapping(value="/out")
	public String out(String ci, HttpServletRequest request) throws Exception {
		System.out.println("#### out");
		System.out.println("### CI :: " + ci);
		
		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", ci);
        
        SkmSSO sso = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("A_OUT")
				.parameter(p)
				.method("GET")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso.getCode());
		System.out.println("--------- ----------- --------" );
		if(sso.getCode() == 200) {
			System.out.println(sso.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso.getStatus();
		
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println(sso.getToken());
	            HttpSession session = request.getSession();
		        session.removeAttribute("token");
	            session.removeAttribute("sci");
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso.getCode());
		}
		
        
		return "redirect:index";
	}
	@RequestMapping(value="/save")
	public String save( String birth,
						String ci,
						String di,
						String safeKey,
						String memId,
						String memNm,
						String email,
						String phone) throws Exception {

		System.out.println("########## save");
		Map<String, Object> p = new HashMap<String, Object>();
        p.put("birth", birth);
        p.put("di", di);
        p.put("ci", ci);
        p.put("safeKey", safeKey);
        p.put("memId", memId);
        p.put("memNm", memNm);
        p.put("email", email);
        p.put("phone", phone);
	    
        SkmSSO sso = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("M_SAVE")
				.parameter(p)
				.method("POST")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso.getCode());
		System.out.println("--------- ----------- --------" );
		if(sso.getCode() == 200) {
			System.out.println(sso.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso.getStatus();
		
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println(sso.getToken());
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso.getCode());
		}
		return "redirect:index";
	}
	
	@RequestMapping(value="/agreeChk")
	@ResponseBody
	public Map<String, Object> agreeChk(@RequestParam("siteId") String siteId, @RequestParam("ci") String ci) throws Exception {
		
		System.out.println("########## agreeChk");
		System.out.println("########## ci :: " + ci);
		System.out.println("########## siteId :: " + siteId);
		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", ci);
        p.put("siteId", siteId);
	    
        SkmSSO sso = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("S_CHK")
				.parameter(p)
				.method("GET")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso.getCode());
		System.out.println("--------- ----------- --------" );
		
		Map<String, Object> r = new HashMap<String, Object>();
		if(sso.getCode() == 200) {
			System.out.println(sso.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso.getStatus();
		    
		    
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println(sso.getToken());
		    	r = (Map<String, Object>) sso.getData();
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso.getCode());
		}
		return r;
	}
	
	@RequestMapping(value="/agreeIns")
	@ResponseBody
	public Map<String, Object> agreeIns(@RequestParam("siteId") String siteId, @RequestParam("ci") String ci) throws Exception {
		
		System.out.println("########## agreeChk");
		System.out.println("########## ci :: " + ci);
		System.out.println("########## siteId :: " + siteId);
		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", ci);
        p.put("siteId", siteId);
	    
        SkmSSO sso = new Conn.SkmSSO(StringConst.SITE_ID,StringConst.KEY)
				.mode("S_SAVE")
				.parameter(p)
				.method("GET")
				.call();

		System.out.println("--------- result DATA --------" );
		System.out.println(sso.getCode());
		System.out.println("--------- ----------- --------" );
		
		Map<String, Object> r = new HashMap<String, Object>();
		if(sso.getCode() == 200) {
			System.out.println(sso.getToken());	
			
		    Map<String, Object> status = (Map<String, Object>) sso.getStatus();
		    
		    
		    System.out.println("======================> " + status.get("status"));
		    if("OK".equals(status.get("status"))) {
		    	System.out.println(sso.getToken());
		    	r = (Map<String, Object>) sso.getData();
		    }else {
		    	System.out.println("# 오류 상태 :: " + status.get("status"));
		    	System.out.println("# 오류 내용 :: " + status.get("message"));	
		    }
		}else {
			System.out.println("########## 시스템 오류발생 :: " +  sso.getCode());
		}
		return r;
	}
}
