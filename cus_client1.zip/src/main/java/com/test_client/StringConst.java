package com.test_client;

public class StringConst {
	
	public static String SITE_ID = "SVC000";
	public static String KEY = "1234567898765431";
}
