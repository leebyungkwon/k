package skmssolib;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import skmssolib.config.api.Conn;
import skmssolib.config.api.Conn.SkmSSO;


public class access {

	public void excute() throws IOException, Exception {
		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", "abc");
        
        
		SkmSSO sso = new Conn.SkmSSO("SVC000", "1234567898765431")
						.mode("A_ACCESS")
						.parameter(p)
						.method("GET")
						.call();
		
        System.out.println("--------- result DATA --------" );
        System.out.println(sso.getCode());
        System.out.println("--------- ----------- --------" );
        if(sso.getCode() == 200) {
        	System.out.println(sso.getToken());	
        	
            Map<String, Object> status = (Map<String, Object>) sso.getStatus();

            System.out.println("======================> " + status.get("status"));
	        if("OK".equals(status.get("status"))) {
	        	System.out.println("##����");
	        	Map<String, Object> r = (Map<String, Object>) sso.getData(); 
	        	System.out.println(r);
	        	for (Entry<String, Object> entry : r.entrySet()) {
	        	    System.out.println("[Key]:" + entry.getKey() + " [Value]:" + entry.getValue());
	        	}
	        }else {
	        	System.out.println("# ���� ���� :: " + status.get("status"));
	        	System.out.println("# ���� ���� :: " + status.get("message"));	
	        }
        }else {
        	System.out.println("########## �ý��� �����߻� :: " +  sso.getCode());
        }
	}
	
	
}
