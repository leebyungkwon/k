package skmssolib.util;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class SsoUtil {
	
	
	 public static Object setMap(String value) throws IOException, ScriptException {
        ScriptEngineManager sem = new ScriptEngineManager();
        ScriptEngine engine = sem.getEngineByName("javascript");

        String json = value;
        String script = "Java.asJSONCompatible(" + json + ")";
        Object result = engine.eval(script);
        
        if (result instanceof List) {
            List<Map> contents = (List<Map>)result;
    		return contents;
        } else if (result instanceof Map) {
        	Map contents  = (Map) result;
    		return contents;
        } else {
        	return null;
        }
        
	 }
}
