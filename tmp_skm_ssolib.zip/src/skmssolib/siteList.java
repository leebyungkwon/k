package skmssolib;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import skmssolib.config.api.Conn;
import skmssolib.config.api.Conn.SkmSSO;

public class siteList {

	public void excute() throws IOException, Exception {
		Map<String, Object> p1 = new HashMap<String, Object>();
        p1.put("ci", "bbbbbbbbbb");

		SkmSSO sso = new Conn.SkmSSO("SVC000", "1234567898765431")
						.mode("S_LIST")
						.parameter(p1)
						.method("GET")
						.call();
        
		System.out.println("--------- result DATA --------" );
        System.out.println(sso.getCode());
        System.out.println("--------- ----------- --------" );
        if(sso.getCode() == 200) {
        	System.out.println(sso.getToken());	
        	
            Map<String, Object> status = (Map<String, Object>) sso.getStatus();

            System.out.println("======================> " + status.get("status"));
	        if("OK".equals(status.get("status"))) {
	        	System.out.println("##����");
	        	List<Map<String, Object>> r =  (List<Map<String, Object>>) sso.getData();
	         	System.out.println("### length :: " + r.size());
	             for(int i=0;i<r.size();i++) {
	             	System.out.println(r.get(i));
	             	Iterator<Entry<String, Object>> entries = r.get(i).entrySet().iterator();
	             	while(entries.hasNext()){
	     	        	Entry<String,Object> entry = (Entry<String,Object>)entries.next();
	     	        	System.out.println("key : " + entry.getKey() + " , value : " + entry.getValue());
	             	}
	             }
	        }else {
	        	System.out.println("# ���� ���� :: " + status.get("status"));
	        	System.out.println("# ���� ���� :: " + status.get("message"));	
	        }
        }else {
        	System.out.println("########## �ý��� �����߻� :: " +  sso.getCode());
        }
	}
}
