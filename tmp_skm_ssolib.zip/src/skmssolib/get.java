package skmssolib;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import skmssolib.config.api.Conn;
import skmssolib.config.api.Conn.SkmSSO;


public class get {

	public void excute() throws IOException, Exception {
		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", "abc");
        p.put("memNm", null);
        
		SkmSSO sso = new Conn.SkmSSO("SVC000", "1234567898765431")
						.mode("M_GET")
						.parameter(p)
						.method("GET")
						.call();
						
        
        System.out.println("--------- result DATA --------" );
        System.out.println(sso.getCode());
        if(sso.getCode() == 200) {
        	List<Map<String, Object>> rData =  (List<Map<String, Object>>) sso.getData();
        	System.out.println("### length :: " + rData.size());
            for(int i=0;i<rData.size();i++) {
            	System.out.println(rData.get(i));
            	Iterator<Entry<String, Object>> entries = rData.get(i).entrySet().iterator();
            	while(entries.hasNext()){
    	        	Entry<String,Object> entry = (Entry<String,Object>)entries.next();
    	        	System.out.println("key : " + entry.getKey() + " , value : " + entry.getValue());
            	}
            }	
        }else {
        	System.out.println("########## �����߻� :: " +  sso.getCode());
        }
	}
}
