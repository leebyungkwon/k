package skmssolib;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import skmssolib.config.api.Conn;
import skmssolib.config.api.Conn.SkmSSO;

public class save {
	
	public void excute() throws IOException, Exception {
		System.out.println("########## save");
		Map<String, Object> p = new HashMap<String, Object>();
	    p.put("birth", "820101");
	    p.put("ci", "kktthh");
	    p.put("di", "d5hn8dsa");
	    p.put("safeKey", "1adbf21");
	    p.put("memId", "kimtaehee");
	    p.put("memNm", "������");
	    p.put("phone", "010001111333");
	    p.put("email", "kimtaehee@naver.com");

		SkmSSO sso = new Conn.SkmSSO("SVC000", "1234567898765431")
						.mode("M_SAVE")
						.parameter(p)
						.method("POST")
						.call();
		
		System.out.println("--------- result DATA --------" );
        System.out.println(sso.getCode());
        System.out.println("--------- ----------- --------" );
        if(sso.getCode() == 200) {
        	System.out.println(sso.getToken());	
        	
            Map<String, Object> status = (Map<String, Object>) sso.getStatus();
        	System.out.println(status.get("status"));
        	System.out.println(status.get("message"));

            System.out.println("========================" );
        	
        	Map<String, Object> r = (Map<String, Object>) sso.getData(); 
        	System.out.println(r);
        	for (Entry<String, Object> entry : r.entrySet()) {
        	    System.out.println("[Key]:" + entry.getKey() + " [Value]:" + entry.getValue());
        	}
        }else {
        	System.out.println("########## �ý��� �����߻� :: " +  sso.getCode());
            Map<String, Object> status = (Map<String, Object>) sso.getStatus();
        	System.out.println(status.get("status"));
        	System.out.println(status.get("message"));
        }	
    }
}
