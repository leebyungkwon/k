package skmssolib;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import skmssolib.config.api.Conn;
import skmssolib.config.api.Conn.SkmSSO;


public class out {

	public void excute() throws IOException, Exception {
		Map<String, Object> p = new HashMap<String, Object>();
        p.put("ci", "bbbbbbbbbb");
        
		SkmSSO sso = new Conn.SkmSSO("SVC000", "1234567898765431")
						.mode("A_OUT")
						.parameter(p)
						.method("GET")
						.call();
		
        System.out.println("--------- result DATA --------" );
        System.out.println(sso.getCode());
        Map<String, Object> rData = (Map<String, Object>) sso.getData();
    	System.out.println(rData);
    	System.out.println(rData.get("status"));
    	System.out.println(rData.get("message"));
        System.out.println("--------- ----------- --------" );
        if(sso.getCode() == 200) {
	        System.out.println(sso.getToken());	
        }else {
        	System.out.println("########## �����߻� :: " +  sso.getCode());
        	System.out.println(sso.getData());
        }
	}
}
