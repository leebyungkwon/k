package skmssolib;

import java.io.IOException;

public class SsoConnection {
	public static void main(String[] args) throws IOException, Exception {
		//new access().excute();
		//new mlist().excute();
		new mAlist().excute();
		//new siteList().excute();
		//new save().excute();
		//new chk().excute();
		//new get().excute();
		//new agreeIns().excute();
		//new agreeChk().excute();
	}
}