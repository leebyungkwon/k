package skmssolib.config;

public class StringConst {
	
	public final static String Domain = "http://localhost:8080";
	//public final static String Domain = "https://devsso.service.skmagic.com";
	public final static String SEEDKEY = "SKMAGICSSOV00001";
	
	public final static String A_ACCESS = "/auth/access";
	public final static String A_GET = "/auth/get";
	public final static String A_OUT = "/auth/out";
	public final static String A_CHK = "/auth/check";
	
	public final static String M_SAVE = "/mem/save";
	public final static String M_GET = "/mem/get";
	public final static String M_LIST = "/mem/list";
	public final static String M_ALIST = "/mem/allList";
	
	public final static String S_LIST = "/site/list";
	public final static String S_CHK = "/site/check";
	public final static String S_SAVE = "/site/save";
	
	
	
}