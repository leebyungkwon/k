package skmssolib.config.api;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

import skmssolib.config.StringConst;
import skmssolib.util.SEED;
import skmssolib.util.SsoUtil;

public class Conn {
    public Conn() {}
	public static SEED seed = new SEED();
	
    public static class SkmSSO {
    	private String siteId;      	//api siteId
        private String secretKey;      	//api ?��?��릿키
        private String mode="";         //api mode
        private String url="";          //api url
        private Map<String, Object> parameter ;    //api param
        private String token="";        //api ?���? ?��?��
        private String method="";       //
        private Boolean outLog=false;   //
        
        private Object status;
        private Object data;
        private int code;

        public SkmSSO(String siteId, String secretKey) {
        	this.siteId   	= siteId;
            this.secretKey  = secretKey;
        }
        public SkmSSO mode(String mode){
            this.mode = mode;
            return this;
        }
        public SkmSSO url(String url){
            this.url = url;
            return this;
        }
        public SkmSSO parameter(Map<String, Object> p){
            this.parameter = p;
            return this;
        }
        public SkmSSO token(String token){
            this.token = token;
            return this;
        }
        public SkmSSO method(String method){
            this.method = method;
            return this;
        }
        public SkmSSO outLog(Boolean outLog){
            this.outLog = outLog;
            return this;
        }

        public SkmSSO call() throws IOException, Exception {
            setUrl();
            
            System.out.println("#### url = " + this.url);
            String p = objectToParam(this.parameter, this.secretKey);
            
        	HttpConnection con = new HttpConnection();
        	con.url(this.url);
        	con.params(p);
        	con.method(this.method);
        	con.header("site", this.siteId);
        	con.header("secretKey", this.secretKey);
        	String rst = (String) con.excute();
        	
        	System.out.println("###### OUTPUT :: " + rst);
        	Map<String,Object> r = (Map<String, Object>) SsoUtil.setMap(rst);
        	this.code = con.getCode();
        	this.token = con.getToken();
        	this.status = SsoUtil.setMap(rst);this.data = r.get("data");
        	
        	
            return this;
        }
        
        private void setUrl() {
        	switch (this.mode) {
			case "A_ACCESS": this.url = StringConst.A_ACCESS;
				break;
			case "A_GET": this.url = StringConst.A_GET;
				break;
			case "A_OUT": this.url = StringConst.A_OUT;
				break;
			case "A_CHK": this.url = StringConst.A_CHK;
				break;
			case "M_SAVE": this.url = StringConst.M_SAVE;
				break;
			case "M_GET": this.url = StringConst.M_GET;
				break;
			case "M_LIST": this.url = StringConst.M_LIST;
				break;
			case "S_LIST": this.url = StringConst.S_LIST;
				break;
			case "S_CHK": this.url = StringConst.S_CHK;
				break;
			case "S_SAVE": this.url = StringConst.S_SAVE;
				break;
			case "M_ALIST": this.url = StringConst.M_ALIST;
				break;
			default:
				break;
			}
        }
        public Object getStatus() {
        	return this.status;
        }
        public Object getData() {
        	return this.data;
        }
        public int getCode() {
        	return this.code;
        }
        public String getToken() {
        	return this.token;
        }
        
    }
    
    private static String objectToParam(Map<String, Object> parameter, String secret) throws UnsupportedEncodingException, Exception {
    	if(parameter == null) return null;
    	
    	String p = "?";
    	
	    for (String key : parameter.keySet()) {
	    	
	    	String val = (String) parameter.get(key);
	    	if(val != null && !val.isEmpty()) {
	    		val = val.trim();
		    	if(!"token".equals(key)) val = URLEncoder.encode(seed.encrypt(val, secret));
		    	else val = URLEncoder.encode(val);
		    	
	    		if(!"?".equals(p)) p = p + "&";
	    		
	    		p = p + key + "="+val;
	    	}
	    }
    	return p;
    }
}
