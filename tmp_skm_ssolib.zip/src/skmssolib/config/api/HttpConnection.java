package skmssolib.config.api;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import skmssolib.config.StringConst;

public class HttpConnection {
	public HttpConnection() {}
	private HttpURLConnection con = null;

	private String url;
	private String param;
	private String method;
	
	private int code;
	
	private String token;
	
	List<Map<String, Object>> head = new ArrayList<Map<String, Object>>();
	public HttpConnection url(String url) throws Exception {
		this.url = url;
		return this;
	}
	public HttpConnection method(String method) throws Exception {
		this.method = method;
		return this;
	}
	
	public HttpConnection params(String p) {
		this.param = p;
		return this;
	}

	private HttpConnection setting() throws Exception {
		this.con.setConnectTimeout(10000); //������ ����Ǵ� Timeout �ð� ����
		this.con.setReadTimeout(10000); 	 // InputStream �о� ���� Timeout �ð� ����
		this.con.setDoOutput(false); 
		return this;
	}
	public HttpConnection header(String key, String val) {
		Map<String, Object> p = new HashMap<String, Object>();
		p.put(key, val);
		head.add(p);
		return this;
	}

	public int getCode() {
		return this.code;
	}

	public String getToken() {
		return this.token;
	}
	
	private void setHead() {
		for(Map<String, Object> el : this.head){
			for(Map.Entry ent : el.entrySet()) {
				this.con.setRequestProperty((String)ent.getKey(), (String)ent.getValue());
			}
		}
	}
	public Object excute() {
		Object msg = "";
		try { 
			URL url  = new URL(StringConst.Domain+this.url+this.param);
			this.con = (HttpURLConnection) url.openConnection();
			this.setting();
			this.setHead();
			con.setRequestMethod(this.method);
			
			StringBuilder sb = new StringBuilder();
			
			this.code = con.getResponseCode();
			this.token = con.getHeaderField("Authorization");
			
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "utf-8"));
				String line;
				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				msg = sb.toString();
			} else {
				msg = con.getResponseMessage();
			}
			
		} catch (Exception e) {
			System.err.println(e.toString());
		}finally {
			return msg;
		}
	}
	
}
