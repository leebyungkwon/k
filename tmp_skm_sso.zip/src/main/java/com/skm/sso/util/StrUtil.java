package com.skm.sso.util;

public class StrUtil {
	public static boolean isStr(String str) {
	  return str == null || str.equals("");
	}
}
