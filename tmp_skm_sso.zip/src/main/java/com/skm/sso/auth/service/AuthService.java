package com.skm.sso.auth.service;

import java.time.LocalDateTime;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.skm.sso.auth.domain.TokenDomain;
import com.skm.sso.auth.repository.AuthRepository;
import com.skm.sso.config.ResponseMsg;
import com.skm.sso.config.enc.SsoUtil;
import com.skm.sso.config.exception.ExceptionCustom;
import com.skm.sso.member.domain.MemDomain;
import com.skm.sso.member.domain.MemSiteMapDomain;
import com.skm.sso.member.repository.MemRepository;
import com.skm.sso.member.repository.MemSiteMapRepository;
import com.skm.sso.site.domain.AgreeDomain;
import com.skm.sso.site.domain.SiteDomain;
import com.skm.sso.site.repository.AgreeRepository;
import com.skm.sso.site.repository.SiteRepository;
import com.skm.sso.util.StrUtil;

@Service
public class AuthService {

	@Autowired private AuthRepository authRepo;
	@Autowired private MemRepository memRepo;
	@Autowired private SiteRepository siteRepo;
	@Autowired private AgreeRepository agreeRepo;
	
	@Autowired private MemSiteMapRepository memSiteMapRepo;
	public TokenDomain save(TokenDomain auth){
		return authRepo.save(auth); 
	}
	
	@Transactional
	public void saveToken(String sid, String ci, String secretKey, String token){
		
		ci = SsoUtil.decrypt(ci,secretKey);
		
		/* 1. 필수 파라미터 확인 */
		if(StrUtil.isStr(sid) || StrUtil.isStr(ci)) throw new ExceptionCustom(HttpStatus.BAD_REQUEST , "P0001");

		/* 2. 유효한 사용자 체크 */
		MemDomain mem = memRepo.findByCi(ci);
		if(mem == null) throw new ExceptionCustom(HttpStatus.BAD_REQUEST ,"M0001");
		
		
		LocalDateTime now = LocalDateTime.now(); 
		LocalDateTime expireDt = now.plusHours(1); //토큰만료 시간을 한시간 이후로 설정
		
		TokenDomain tokenDomain = new TokenDomain();
		tokenDomain.setSid(sid);
		tokenDomain.setCi(ci);
		tokenDomain.setExpireDt(expireDt);
		tokenDomain.setToken(token);
		authRepo.save(tokenDomain);
		
		mem.setTokenRegDt(now);
		mem.setToken(token);
		memRepo.save(mem); 
	}

	public String getToken(String ci) {
		/* 1. 필수 파라미터 확인 */
		if(StrUtil.isStr(ci)) throw new ExceptionCustom(HttpStatus.BAD_REQUEST ,"P0001");
		
		/* 2. 유효한 사용자 체크 */
		MemDomain mem = memRepo.findByCi(ci);
		if(mem == null) throw new ExceptionCustom(HttpStatus.BAD_REQUEST ,"M0001");
		if(StrUtil.isStr(mem.getToken())) throw new ExceptionCustom(HttpStatus.BAD_REQUEST ,"M0002");

		/* 3. Token만료 여부 */
		TokenDomain pToken = new TokenDomain();
		pToken.setToken(mem.getToken());
		TokenDomain rToken = authRepo.findByToken( mem.getToken());
		if(rToken == null) throw new ExceptionCustom(HttpStatus.BAD_REQUEST ,"M0003");
		
		return mem.getToken();
	}

	public Object checkToken(String token, String sid, String ci, String siteId) {

		/* 1. 필수 파라미터 확인 */
		if(StrUtil.isStr(ci) || StrUtil.isStr(siteId)) return new ResponseMsg(HttpStatus.BAD_REQUEST,"P0001");
		
		/* 2. 유효한 사용자 체크 */
		MemSiteMapDomain memSite = memSiteMapRepo.findByCiAndSiteId(ci,sid);
		if(memSite == null) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"M0001"); 
		MemDomain mem = memRepo.findByCi(ci);
		if(mem == null) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"M0001");
		if(StrUtil.isStr(mem.getToken())) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"M0002");
		if(!mem.getToken().equals(token)) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"M0003");

		AgreeDomain agreeDomain = agreeRepo.check(ci,sid,siteId);
		if(agreeDomain == null) return new ResponseMsg(HttpStatus.NO_CONTENT ,"D0003");
		
		TokenDomain pToken = new TokenDomain();
		pToken.setCi(ci);
		pToken.setToken(token);
		TokenDomain rToken = authRepo.findByToken(token);
		return new ResponseMsg(HttpStatus.OK ,"A0001", rToken);
	}
	

	public TokenDomain inValidToken(String ci) {
		return authRepo.inValidToken(ci);
	}
}
