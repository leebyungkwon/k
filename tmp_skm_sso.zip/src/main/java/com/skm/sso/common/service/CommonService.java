package com.skm.sso.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.skm.sso.config.ResponseMsg;
import com.skm.sso.config.exception.ExceptionCustom;
import com.skm.sso.site.domain.SiteDomain;
import com.skm.sso.site.repository.SiteRepository;
import com.skm.sso.util.StrUtil;

@Service
public class CommonService {

	@Autowired private SiteRepository siteRepo;
	
	public Object isValidSite(String siteId, String secretKey) {
		/* 1. 필수 파라미터 체크 */
		if(StrUtil.isStr(siteId) || StrUtil.isStr(secretKey)){
			return new ResponseMsg(HttpStatus.BAD_REQUEST ,"P0001");
		}
		/* 2. 유효한 사이트 체크 */
		SiteDomain site = siteRepo.findBySiteIdAndSecretKey(siteId, secretKey);
		if(site == null) return new ResponseMsg(HttpStatus.UNAUTHORIZED ,"S0002");

		return new ResponseMsg(HttpStatus.OK ,"A0001", site);
	}

	public SiteDomain findBySiteIdAndSecretKey(String siteId, String secretKey) {
		return siteRepo.findBySiteIdAndSecretKey(siteId, secretKey);
	}

}
