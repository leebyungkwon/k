package com.skm.sso.site.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicInsert;

import lombok.Data;

@Data
@Entity(name="site_agree")
@IdClass(AgreeKey.class)
@DynamicInsert
public class AgreeDomain  {

	@Id
	private String ci;
	@Id
	private String siteId1;
	@Id
	private String siteId2;

	@ColumnDefault("'Y'")  
    @Column(updatable=false)
	private String useYn;

    @CreationTimestamp
    @Column(updatable=false)
	private LocalDateTime regDt;
}