package com.skm.sso.site.controller;

import java.security.NoSuchAlgorithmException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skm.sso.common.service.CommonService;
import com.skm.sso.config.ResponseMsg;
import com.skm.sso.site.service.SiteService;

@Controller
@RestController
@RequestMapping("/site")
public class SiteController {

	@Resource private SiteService siteService;
	@Resource private CommonService commonService;
	
	@RequestMapping("/list")
	public ResponseEntity<ResponseMsg> list(){
		ResponseMsg responseMsg = (ResponseMsg) siteService.findAll();
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
	@RequestMapping("/check")
	public ResponseEntity<ResponseMsg> check(String ci, String siteId, HttpServletResponse response, HttpServletRequest request) throws NoSuchAlgorithmException{
		String sid = request.getHeader("Site");
		String secretKey = request.getHeader("SecretKey");
		
		ResponseMsg responseMsg = (ResponseMsg) commonService.isValidSite(sid, secretKey);
		if(responseMsg.isError()) 		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
		
		responseMsg = (ResponseMsg) siteService.agreeCheck(ci, siteId, sid, secretKey);
		
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
	@RequestMapping("/save")
	public ResponseEntity<ResponseMsg> save(String ci, String siteId, HttpServletResponse response, HttpServletRequest request) throws NoSuchAlgorithmException{
		String sid = request.getHeader("Site");
		String secretKey = request.getHeader("SecretKey");
		
		ResponseMsg responseMsg = (ResponseMsg) commonService.isValidSite(sid, secretKey);
		if(responseMsg.isError()) 		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
		
		responseMsg = (ResponseMsg) siteService.agreeSave(ci, siteId, sid, secretKey);
		
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
}
