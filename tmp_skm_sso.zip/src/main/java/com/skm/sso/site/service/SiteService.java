package com.skm.sso.site.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.skm.sso.config.ResponseMsg;
import com.skm.sso.config.enc.SsoUtil;
import com.skm.sso.site.domain.AgreeDomain;
import com.skm.sso.site.domain.SiteDomain;
import com.skm.sso.site.repository.AgreeRepository;
import com.skm.sso.site.repository.SiteRepository;
import com.skm.sso.util.StrUtil;

@Service
public class SiteService {


	@Autowired private SiteRepository siteRepo;
	@Autowired private AgreeRepository agreeRepo;
	
	public Object findAll() {
		
		List<SiteDomain> domain = (List<SiteDomain>) siteRepo.findAll();
		if(domain == null) return new ResponseMsg(HttpStatus.NO_CONTENT ,"D0002");
		
		return new ResponseMsg(HttpStatus.OK ,"A0001", domain);
	}
	public Object agreeSave(String ci, String siteId, String sid, String secretKey) {
		
		/* 1. 필수 파라미터 확인 */
		if(StrUtil.isStr(sid) || StrUtil.isStr(ci)) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"P0001");
		
		AgreeDomain agree = new AgreeDomain();
		agree.setCi(SsoUtil.decrypt(ci,secretKey));
		agree.setSiteId1(SsoUtil.decrypt(siteId,secretKey));
		agree.setSiteId2(sid);
		return new ResponseMsg(HttpStatus.OK ,"A0001", agreeRepo.save(agree));
	}
	public ResponseMsg agreeCheck(String ci, String siteId, String sid, String secretKey) {
		
		/* 1. 필수 파라미터 확인 */
		if(StrUtil.isStr(sid) || StrUtil.isStr(ci)) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"P0001");

		ci = SsoUtil.decrypt(ci,secretKey);
		siteId = SsoUtil.decrypt(siteId,secretKey);
		
		AgreeDomain agreeDomain = agreeRepo.check(ci,sid,siteId);
		if(agreeDomain == null) return new ResponseMsg(HttpStatus.NO_CONTENT ,"D0003");
		
		return new ResponseMsg(HttpStatus.OK ,"A0001", agreeDomain);
	}

}