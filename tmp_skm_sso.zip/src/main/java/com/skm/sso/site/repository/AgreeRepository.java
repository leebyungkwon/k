package com.skm.sso.site.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.skm.sso.site.domain.AgreeDomain;
import com.skm.sso.site.domain.AgreeKey;

@Repository
public interface AgreeRepository extends CrudRepository<AgreeDomain, AgreeKey> {
	public AgreeDomain save(AgreeDomain agree);

	@Query("select a from site_agree a where ((site_id1 = ?2 or site_id2 = ?2) and (site_id1 = ?3 or site_id2 = ?3)) and ci = ?1 ")
	public AgreeDomain check(String ci, String sid, String siteId);
}