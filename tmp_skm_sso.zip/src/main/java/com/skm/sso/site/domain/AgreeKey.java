package com.skm.sso.site.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgreeKey implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String ci;
	private String siteId1;
	private String siteId2;
}