package com.skm.sso.member.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.skm.sso.member.domain.MemDomain;

@Repository
public interface MemRepository extends CrudRepository<MemDomain, String> {
	
	public MemDomain findByCi(String ci);
	public MemDomain save(MemDomain mem);
	
	
	@Modifying
	@Transactional
	@Query("UPDATE member a SET a.token = null , token_reg_dt = null WHERE a.ci = ?1")
	public int saveNullToken(String ci);
	
	public MemDomain findByCiAndToken(String ci, String token);


}
