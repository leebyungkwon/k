package com.skm.sso.member.controller;


import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skm.sso.common.service.CommonService;
import com.skm.sso.config.ResponseMsg;
import com.skm.sso.config.enc.SsoUtil;
import com.skm.sso.config.exception.ExceptionCustom;
import com.skm.sso.member.domain.MemDomain;
import com.skm.sso.member.domain.MemSiteMapDomain;
import com.skm.sso.member.service.MemService;
import com.skm.sso.site.domain.SiteDomain;

@RestController
@RequestMapping("/mem")
public class MemController {
	
	@Autowired private MemService memService;
	@Autowired private CommonService commonService;
	
	@GetMapping(value="/test")
	public String test(){
		return "######### success connecting";
	}
	
	/**
	 * 고객정보 저장
	 * @param mem
	 * @param sid
	 * @return
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException                                                                                     
	 */
	@PostMapping(value="/save")
	public ResponseEntity<ResponseMsg> save(MemSiteMapDomain mem, HttpServletRequest request) throws IllegalArgumentException, IllegalAccessException{
		String sid = request.getHeader("site");
		String secretKey = request.getHeader("SecretKey");
		
		ResponseMsg responseMsg = (ResponseMsg) commonService.isValidSite(sid, secretKey);
		if(responseMsg.isError()) 		return new ResponseEntity<>(responseMsg, HttpStatus.OK);

		SiteDomain site = commonService.findBySiteIdAndSecretKey(sid, secretKey); 
		site.setSecretKey(secretKey);
		responseMsg = (ResponseMsg) memService.save(mem, site);
				
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
	
	@GetMapping(value="/get")
	public ResponseEntity<ResponseMsg> get(MemSiteMapDomain mem, HttpServletRequest request) throws IllegalArgumentException, IllegalAccessException{
		String sid = request.getHeader("site");
		String secretKey = request.getHeader("SecretKey");

		ResponseMsg responseMsg = (ResponseMsg) commonService.isValidSite(sid, secretKey);
		if(responseMsg.isError())	return new ResponseEntity<>(responseMsg, HttpStatus.OK);
		
		responseMsg = (ResponseMsg) memService.findBySiteMember(mem,secretKey);
		
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
	@GetMapping(value="/list")
	public ResponseEntity<ResponseMsg> list(MemDomain mem, HttpServletRequest request) throws IllegalArgumentException, IllegalAccessException{
		String sid = request.getHeader("site");
		String secretKey = request.getHeader("SecretKey");

		ResponseMsg responseMsg = (ResponseMsg) commonService.isValidSite(sid, secretKey);
		if(responseMsg.isError())	return new ResponseEntity<>(responseMsg, HttpStatus.OK);
		
		responseMsg = (ResponseMsg) memService.findBySiteId(mem,sid);
		
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}

	@GetMapping(value="/allList")
	public ResponseEntity<ResponseMsg> allList(MemDomain mem, HttpServletRequest request) throws IllegalArgumentException, IllegalAccessException{
		String sid = request.getHeader("site");
		String secretKey = request.getHeader("SecretKey");

		ResponseMsg responseMsg = (ResponseMsg) commonService.isValidSite(sid, secretKey);
		if(responseMsg.isError())	return new ResponseEntity<>(responseMsg, HttpStatus.OK);
		
		responseMsg = (ResponseMsg) memService.findAll();
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}

}
