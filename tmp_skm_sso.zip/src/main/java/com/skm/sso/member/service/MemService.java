package com.skm.sso.member.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.skm.sso.config.ResponseMsg;
import com.skm.sso.config.enc.SsoUtil;
import com.skm.sso.config.exception.ExceptionCustom;
import com.skm.sso.member.domain.MemDomain;
import com.skm.sso.member.domain.MemSiteMapDomain;
import com.skm.sso.member.repository.MemRepository;
import com.skm.sso.member.repository.MemSiteMapRepository;
import com.skm.sso.site.domain.AgreeDomain;
import com.skm.sso.site.domain.SiteDomain;
import com.skm.sso.util.StrUtil;

@Service
public class MemService {

	@Autowired private MemRepository memRepo;
	@Autowired private MemSiteMapRepository memSiteMapRepo;
	

	@Transactional
	public Object save(MemSiteMapDomain mapDomain, SiteDomain site){
		String secretKey = site.getSecretKey();
		String ci = SsoUtil.decrypt(mapDomain.getCi(),secretKey);
		String di = SsoUtil.decrypt(mapDomain.getDi(),secretKey);

		/* 1. 필수 파라미터 확인 */
		if(StrUtil.isStr(ci)) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"P0001");
		
		mapDomain.setCi(ci);
		mapDomain.setDi(di);
		mapDomain.setSiteId(site.getSiteId());
		mapDomain.setMemId(SsoUtil.decrypt(mapDomain.getMemId(),secretKey));
		mapDomain.setMemNm(SsoUtil.decrypt(mapDomain.getMemNm(),secretKey));
		mapDomain.setBirth(SsoUtil.decrypt(mapDomain.getBirth(),secretKey));
		mapDomain.setPhone(SsoUtil.decrypt(mapDomain.getPhone(),secretKey));
		mapDomain.setEmail(SsoUtil.decrypt(mapDomain.getEmail(),secretKey));
		mapDomain.setSafeKey(SsoUtil.decrypt(mapDomain.getSafeKey(),secretKey));
		MemDomain mem = new MemDomain();
		mem.setCi(ci);
		mem.setDi(di);
		mem.setSafeKey(mapDomain.getSafeKey());
		
		memSiteMapRepo.save(mapDomain);
		return new ResponseMsg(HttpStatus.OK ,"A0001", memRepo.save(mem));
	}
	
	@Transactional
	public Object saveNullToken(String ci) {

		/* 1. 필수 파라미터 확인 */
		if(StrUtil.isStr(ci)) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"P0001");

		/* 2. 유효한 사용자 체크 */
		MemDomain mem = memRepo.findByCi(ci);
		if(mem == null) return new ResponseMsg(HttpStatus.BAD_REQUEST ,"M0001");
		
		return new ResponseMsg(HttpStatus.OK ,"A0001", memRepo.saveNullToken(ci)); 
	}

	@Transactional
	public List<MemSiteMapDomain> findByCi(MemDomain mem,String secretKey) {
		String ci = SsoUtil.decrypt(mem.getCi(),secretKey);
		if(StrUtil.isStr(ci)) throw new ExceptionCustom(HttpStatus.BAD_REQUEST ,"P0001");
		
		return memSiteMapRepo.findByCi(ci);
	}
	
	@Transactional
	public Object findBySiteId(MemDomain mem,String siteId) {
		if(StrUtil.isStr(siteId)) throw new ExceptionCustom(HttpStatus.BAD_REQUEST ,"P0001");
		
		List<MemSiteMapDomain> domain = (List<MemSiteMapDomain>) memSiteMapRepo.findBySiteId(siteId);
		if(domain == null || domain.size() == 0) return new ResponseMsg(HttpStatus.NO_CONTENT ,"D0002");
		
		return new ResponseMsg(HttpStatus.OK ,"A0001", domain);
	}

	public Object findAll() {

		List<MemSiteMapDomain> domain = (List<MemSiteMapDomain>) memSiteMapRepo.findAll();
		if(domain == null || domain.size() == 0) return new ResponseMsg(HttpStatus.NO_CONTENT ,"D0002");
		
		return new ResponseMsg(HttpStatus.OK ,"A0001", domain);
	}

	public MemDomain findByCi(String ci) {
		return memRepo.findByCi(ci);
	}

	public Object findBySiteMember(MemSiteMapDomain mem, String secretKey) {
		String ci = SsoUtil.decrypt(mem.getCi(),secretKey);
		String memNm = SsoUtil.decrypt(mem.getMemNm(),secretKey);
		String birth = SsoUtil.decrypt(mem.getBirth(),secretKey);
		String phone = SsoUtil.decrypt(mem.getPhone(),secretKey);
		
		List<MemSiteMapDomain> domain =  memSiteMapRepo.findBySiteMember(ci, memNm, birth, phone);
		if(domain == null || domain.size() == 0) return new ResponseMsg(HttpStatus.NO_CONTENT ,"D0002");
		
		return new ResponseMsg(HttpStatus.OK ,"A0001", domain);
	}

}