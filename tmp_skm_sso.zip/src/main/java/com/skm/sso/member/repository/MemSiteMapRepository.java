package com.skm.sso.member.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.skm.sso.member.domain.MemSiteMapDomain;
import com.skm.sso.member.domain.MemSiteMapKey;

@Repository
public interface MemSiteMapRepository extends CrudRepository<MemSiteMapDomain, MemSiteMapKey> {
	public MemSiteMapDomain save(MemSiteMapDomain mem);

	public List<MemSiteMapDomain> findByCi(String ci);

	public List<MemSiteMapDomain> findBySiteId(String siteId);

	public MemSiteMapDomain findByCiAndSiteId(String ci, String sid);
	
	@Query("select msm from member_site_map msm	where (msm.ci = ?1) or (mem_nm=?2 and birth=?3 and phone=?4)")
	public List<MemSiteMapDomain> findBySiteMember(String ci, String memNm, String birth, String phone);
}