package com.skm.sso.member.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity(name="member")
public class MemDomain {
	
	@Id
    public String ci;
	
    public String di;
	
	private String safeKey;
	private String token;
	
    @CreationTimestamp
	private LocalDateTime regDt;
	
	private LocalDateTime tokenRegDt;
	
    
}