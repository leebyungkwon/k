package com.skm.sso.config.enc;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Base64.Decoder;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.skm.sso.config.StringConst;

public class SsoUtil {
	
	public static byte[] generateToken(String enc) throws NoSuchAlgorithmException {
		SimpleDateFormat formatter = new SimpleDateFormat ("yyyyMMddhhmmss");
		Calendar cal = Calendar.getInstance();
		String day = formatter.format(cal.getTime());
		enc = enc+day;
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(enc.getBytes());
	    return md.digest();
	}
	
	public static String bytesToHex(byte[] bytes) {
	    StringBuilder builder = new StringBuilder();
	    for (byte b: bytes) {
	      builder.append(String.format("%02x", b));
	    }
	    return builder.toString();
	}
	
	static String charset = "utf-8";
 
	public static byte pbUserKey[] = new String(StringConst.SEEDKEY).getBytes();
    
    public static String encrypt(String str, String secret) throws UnsupportedEncodingException {
    	byte[] bszIV = new String(secret).getBytes();
        byte[] msg = null;
 
        try {
            msg = KISA_SEED_CBC.SEED_CBC_Encrypt(pbUserKey, bszIV, str.getBytes(charset), 0,
                    str.getBytes(charset).length);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
 
        java.util.Base64.Encoder encoder = Base64.getEncoder();
        byte[] encArray = encoder.encode(msg);
        try {
            System.out.println(new String(encArray, "utf-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return new String(encArray, "utf-8");
    }
    
    public static String decrypt(String str, String secret) {
    	if(str == null || str.isEmpty()) return null;

    	byte[] bszIV = new String(secret).getBytes();
    	Decoder decoder = Base64.getDecoder();
        byte[] msg = decoder.decode(str);
 
        String result = "";
        byte[] dec = null;
 
        try {
            dec = KISA_SEED_CBC.SEED_CBC_Decrypt(pbUserKey, bszIV, msg, 0, msg.length);
            result = new String(dec, charset);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
 
    return result.trim();
}
	
}
