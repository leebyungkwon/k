var to = "";
let GRID = {  
    id			: this.id,
    url			: this.url,
    init		: true,
    search		: "",
    orgData		: "",
    opts		: "",
    gridData	: "",
	rowClick	: false,
	sortNm		: "",
	sort		: "DESC",
    searchSeq		: [],
    searchWidth		: [],
	searchCol 		: [],
	searchDefault	: [],
	isPaging	: true,
	pageCnt		: 0,
	page 		: 0,
	size 		: 10,
	params		: {},
	gridSearch	: "",
	check		: false,
    getId : function(){
        return this.id;
    },
    validation : function(obj){
    	if(obj.id == undefined){
    		alert("그리드 ID 입력하세요.");
    		return;
    	}
    	if(obj.url == undefined){
    		alert("URL 입력하세요.");
    		return;
    	}
    },
    set : function(obj){
    	let _this = this;
    	this.validation(obj);
    	this.id = obj.id;
    	this.url = obj.url;
    	this.rowClick = obj.rowClick;
    	this.search = (obj.search == undefined) ? ""	: obj.search;
    	this.sort = (obj.sort == undefined) ? "DESC"	: obj.sort;
    	this.sortNm = (obj.sortNm == undefined) ? ""	: obj.sortNm;
    	this.isPaging = (obj.isPaging == undefined) ? true	: obj.isPaging;
    	this.page = (obj.page == undefined) ? 0		: obj.page;
    	this.size = (obj.size == undefined) ? 10 		: obj.size;
    	this.gridSearch = (obj.gridSearch == undefined) ? "" : obj.gridSearch ; 
    	this.check = (obj.check == undefined) ? false	: obj.check;
    	this.params = {  
    		'page'		: this.page
    		,'isPaging'	: this.isPaging
    		,'size'		: this.size
    		,'sort'		: this.sortNm+','+this.sort
		};

    	this.opts = obj;
    	this.getData();
    	
    	if(this.gridSearch != "") {
    		document.getElementById(obj.gridSearch).querySelector(".gridSearch").onclick = function() {_this.getData();};
    	}
    },
    getData : function(){
    	let _this = this;
    	
    	let param = "";
    	if(this.gridSearch != "") {
    		param = Object.assign({}, this.params, WebUtil.getTagInParam(document.getElementById(this.gridSearch)));
    	}
		let p = {
			url : this.url
			, param : param
			, success : function (opt,result) {
    	    	_this.setTable(result.data.list);
    	    	if(result.data.list.length <= 0) return;
    	    	if(_this.isPaging && _this.init) _this.setPaging(result.data.pageCnt);
    	    }
		}
		AjaxUtil.post(p);
    },
    setTable : function(data){
    	let _this = this;
    	
    	this.orgData = data;
    	this.gridData = data;
    	
    	let hiddenCol = this.columnSetHiddenCol(this.opts.bodyCol);
    	let table = "";
    	
    	if(this.search != ""){
    		if(this.search.searchUse == "Y"){
    			for(i in obj.bodyCol) {	
    				if(obj.bodyCol[i].search != undefined){
        	    		let typ = this.opts.bodyCol[i].search["type"];
        	    		if(typ != undefined){
        	    			this.searchCol.push(this.opts.bodyCol[i]);
        	    			this.searchSeq.push(i);
        	    			this.searchDefault.push(this.opts.bodyCol[i]["search"]["default"]);
        	    			this.searchWidth.push(this.opts.bodyCol[i]["search"]["width"]);
        	    		}
    				}
    	    	}
    			table += "<table class='searchTable' id='tbl_"+this.id +"_search' style='width:"+this.opts.width+"'>"+ "<tbody></tbody></table>";
    		}
    	}
    	
    	table += "<table class='gridTableHead' id='tbl_"+this.id +"_head' style='width:"+this.opts.width+"'>"
    		+ "<thead></thead></table>";

    	table += "<table class='gridTableBody' id='tbl_"+this.id +"_body' style='width:"+this.opts.width+"'>"
    		+ "<tbody></tbody></table>" ;
    	
    	document.getElementById(this.id).innerHTML = table;

    	if(this.search.searchUse == "Y")	this.setSearch("tbl_"+this.id +"_search", obj.headCol, data);
    	
    	this.setHead("tbl_"+this.id +"_head", this.opts.headCol, hiddenCol, this.opts.bodyCol);
    	this.setBody("tbl_"+this.id +"_body", this.opts.bodyCol, data, hiddenCol);
    	if(this.search != ""){
    		if(this.search.searchUse == "Y"){
    			document.getElementById(this.id+"_search").onclick = function() {_this.searchEvent();};
    		}
    	}
    },
    setData : function(){
    	this.gridData = [];
    	let searchName = [];
    	let searchWay = [];
		if(this.search != ""){
    		if(this.search.searchUse == "Y"){
    			for(i in this.searchCol)	{
    				searchName.push(this.searchCol[i]["name"]);
    				searchWay.push(this.searchCol[i]["search"]["way"]);
    			}
    		}
    	}
		let data = this.orgData; 
		
		let emp = true;
		searchName.forEach( function( v, i ){
			let val = document.getElementById("tbl_"+_this.id+"_search_"+v).value;
			if(val != "전체") {
				emp = false;
				return;
			}
		});
		if(emp){
			this.gridData = data;
		}else{
			this.gridData = data.filter(function(item){ 
				let d = true;
				searchName.forEach( function( v, i ){
					if(!d) return ;	
					if(document.getElementById("tbl_"+_this.id+"_search_"+v).value != "전체"){
						let val = document.getElementById("tbl_"+_this.id+"_search_"+v).value;
						d = (item[v] === document.getElementById("tbl_"+_this.id+"_search_"+v).value);
					}
				});
				return d;
			});
		}
		
		/*
		for(i in data) {
			let inFalg = false;
			let searchValYn = false;
			let tempSearch = [];
			
			for(j in searchName){
				let search_val = document.getElementById("tbl_"+this.id+"_search_"+searchName[j]).value;
				if(search_val != "" && search_val != "전체"){
					tempSearch.push(this.searchCol[j]["name"]);
					searchValYn = true;
				}else{
					searchValYn = false;
				}
			}
			if(tempSearch.length > 0){
				let tempFlag = true;
						
				for(j in tempSearch){
					let search_val = document.getElementById("tbl_"+this.id+"_search_"+tempSearch[j]).value;
					
					 *  AND 로 검색
					

					if(tempFlag){
						if(search_val != "" && search_val != "전체"){
							if(data[i][tempSearch[j]] == search_val){
								console.log(tempSearch[j] +" = " + data[i][tempSearch[j]] + " , " + search_val);
								tempFlag = true;
							}else{
								tempFlag = false;
							}
						}	
					}
					if(tempSearch.length-1 == j && tempFlag) inFalg = true;
					
					 * 
					 *  OR 로 검색
					 * 
					if(!inFalg){
						if(search_val != "" && search_val != "전체"){
							if(data[i][tempSearch[j]] == search_val){
								console.log("[ " + i + " ] 검색 값 :: " + tempSearch[j] + " =  [" + search_val + "] = [" + data[i][tempSearch[j]]+"]");
								inFalg = true;
							}else{
								inFalg = false;
								//continue;
							}
						}
					}
					
				}
				
			}else{
				inFalg = true;
			}

			if(inFalg){
				this.gridData.push(data[i]);
			}
		}
		*/
    },
    setPaging : function(pageCnt){
    	let _this = this;
    	let current = parseInt(_this.params.page)+1;
    	this.pageCnt = pageCnt;
    	let tag = document.createElement("div");
    	let page_id = this.id+"_paging";
    	tag.className = "custom-pagination";
    	tag.id = page_id;
    	let s_tag = "";
    	let start = (parseInt((current-1)/10)*10)+1;
    	let end = start+9;
    	end = (this.pageCnt<end) ? this.pageCnt : end; 
    	if(this.pageCnt>1){
    		if(1 < current) s_tag += '<span  class="pagination-previous"><a class=""><</a></span>';
    		for(let i=start;i<=end;i++){
        		s_tag += '<span class="num num'+i+'"><a class="page_num">'+i+'</a></span>';
    		}
    		if(pageCnt > current) s_tag += '<span  class="pagination-next"><a class="">></a></span>';
    	}
    	tag.innerHTML = s_tag;
    	document.getElementById(this.id).appendChild(tag);
    	

    	let page = document.getElementById(page_id).querySelectorAll(".page_num");
    	let prev = document.getElementById(page_id).querySelector(".pagination-previous");
    	let next = document.getElementById(page_id).querySelector(".pagination-next");
    	if(null != prev){
    		prev.addEventListener('click', function(event) {
	    		for (let __page=0;__page<page;__page++) {
					__page.parentElement.classList.remove("current");
				}
				_this.params.page = _this.params.page - 1; 
				_this.getData();
	    	});
    	}
    	if(null != next){
    		next.addEventListener('click', function(event) {
	    		for (let __page=0;__page<page;__page++) {
    				__page.parentElement.classList.remove("current");
    			}
    			_this.params.page = _this.params.page + 1; 
    			_this.getData();
        	});
    	}
    	
    	let idx = 1;
    	
		for (let _page=0;_page<page.length;_page++) {
			page[_page].addEventListener('click', function(event) {
    			console.log('page',this.text);
	    		for (let __page=0;__page<page.length;__page++) {
	    			page[__page].parentElement.classList.remove("current");
				}
    			_this.params.page = this.text-1; 
    			_this.getData();
    		});
    	}
		if(document.getElementById(page_id).querySelector(".num"+(parseInt(_this.params.page)+1)) != null)
			document.getElementById(page_id).querySelector(".num"+(parseInt(_this.params.page)+1)).className= "num current num"+_this.params.page+1;
    },
    setSearch : function(id, headCol, data){
    	let tag = "<tr>";
    	let colspan = 0;
    	for(i in headCol){
    		for(j in this.searchSeq)	{
    			if(i == j){
    				colspan++;
            		tag += "<td class='searchTableTop'>";
    				tag += "<label>"+headCol[this.searchSeq[j]]+"</label><span>";
    				
    				let selecteName = (this.searchDefault[j] != undefined) ? this.searchDefault[j] : ""; 
    				if(this.searchCol[j].search["type"] == "text"){
    					tag += "<input type='text' name='"+id+"_"+this.searchCol[j].name+"' id='"+id+"_"+this.searchCol[j].name+"' style='margin-left:10px;width:80px;'/>";
    				}
    				else if(this.searchCol[j].search["type"] == "select"){
    					tag += "<select name='"+id+"_"+this.searchCol[j].name+"' id='"+id+"_"+this.searchCol[j].name+"' style='margin-left:10px;width:"+this.searchWidth[j]+";'>";
    					let searchName = this.searchCol[j].name;
    					let _name = [];
    					let prev_name = "";
		    			tag += "<option>전체</option>";
    		    		for(k in data)	{
    		    			if(prev_name != data[k][searchName]){
    		    				prev_name = data[k][searchName];
    		    				let _name_flag = true;
    		    				for(m in _name)	{
    		    					if(_name[m] == prev_name){
    		    						_name_flag = false;
    		    						continue;
    		    					}
    		    				}
    		    				if(_name_flag)	_name.push(prev_name);
    		    			}
    		    		}
    		    		for(k in _name)	{
    		    			let selected = (selecteName == _name[k]) ? "selected" : "";
    		    			tag += "<option value='"+_name[k]+"' "+selected+">"+_name[k]+"</option>";
    		    		}
    					tag += "</select>";
    				}
    				
            		tag += "</span></td>";
    			}
    		}
    	}
    	
    	tag += "</tr>";
    	tag += "<tr class='searchTableSearch'><td id='"+this.id+"_search' colspan='"+colspan+"'>검  색</td></tr>"
    	
    	document.getElementById(id).getElementsByTagName("tbody")[0].innerHTML = tag;
    	
    },
    setHead : function(id, headCol, hiddenCol, bodyCol){
    	let _this = this;
    	let tag = "<tr>";
    	let hiddenStr = "display:none;";
    	if(this.check) tag += "<th style='text-align:center;width:10px;'><input type='checkbox'/></th>";
    	for(i in headCol){
    		tag += "<th style='text-align:center; width:"+bodyCol[i].width+";";
    		for(j in hiddenCol)	if(i == hiddenCol[j])	tag += hiddenStr;
    		tag += "'>"+headCol[i]+"</th>";
    	}
    	tag += "</tr>";
    	document.getElementById(id).getElementsByTagName("thead")[0].innerHTML = tag;
    	if(this.check) {
    		document.getElementById(id).getElementsByTagName("thead")[0].getElementsByTagName("input")[0].onclick = function() {
    			let headCheck = this.checked;
    			if(this.type=='checkbox') {
					let chkBody = document.getElementById("tbl_"+_this.id +"_body").getElementsByTagName("tbody")[0].getElementsByTagName("input");
					[].forEach.call(chkBody, function(el ,idx) {
	    				if(headCheck) el.checked = true;
	    				else el.checked = false;
			    	});
    			}
    		};
    	}
    },
    setBody : function(id, bodyCol,data, hiddenCol){
    	let _this = this;
    	this.setData();
    	
		let tag = "";
    	let hiddenStr = "display:none;";
    	
    	
    	if(this.gridData == 0){
    		tag += "<tr><td colspan='"+bodyCol.length+"' style='text-align:center;font-weight:bold;'>데이터가 없습니다.</td></tr>";
        	document.getElementById(id).getElementsByTagName("tbody")[0].innerHTML = tag;
    	}else{
	    	for(i in this.gridData) {
	    		tag += "<tr>";
	    		if(this.check) tag += "<td class='noClick' style='text-align:center;width:10px;'><input type='checkbox'/></td>";
	    		for(j in bodyCol) {	
	    			let typ = bodyCol[j].type;
	    			let name = bodyCol[j].name;
	    			let dataStr = (this.gridData[i][name] == undefined) ? "" : this.gridData[i][name];
	    			
	    			if(typeof dataStr == 'string')	dataStr = dataStr.unescapeHtml();
	    			
	    			tag += "<td class='tbodyTd' style='";
	    			
	        		for(k in hiddenCol)	if(hiddenCol[k] == j)	tag += hiddenStr;
	        		
	        		let align = (bodyCol[j].align == undefined) ? "center" : bodyCol[j].align;
	        		tag += "text-align:"+align+";" + "width:"+bodyCol[j].width+";'>";
	        		tag += (typ == "text") ? "<input type='text' id='"+name+"' value='"+dataStr+"'/>" : dataStr;
	        		tag += "</td>";
	        		
	    		}
	    		tag += "</tr>";
	    	}
	    	document.getElementById(id).getElementsByTagName("tbody")[0].innerHTML = tag;
	    	if(_this.rowClick){
		    	let tbodyTr = document.getElementById(id).getElementsByTagName("tbody")[0].getElementsByTagName("tr");
		    	//let tbodyTr = document.getElementById(id).getElementsByTagName("tbody")[0].querySelectorAll('td:not([class*="tbodyCheck"])');
		    	[].forEach.call(tbodyTr, function(el ,idx) {
		    		let _el = el.querySelectorAll('td:not([class*="noClick"])');
		    		el.style.cursor = "pointer";
		    		[].forEach.call(_el, function(subEl ,index) {
		    			subEl.onclick = function() {
			    			_this.clickRemove();
							subEl.parentElement.style.background = _this.rowClick.color;
			    			if(_this.rowClick.retFunc != undefined)	_this.rowClick.retFunc(idx, _this.gridData[idx]);	
			    		}
		    		});
		    		
		    	});
	    	}
    	}
    		
    },
    columnSetHiddenCol : function(bodyCol){
    	let hiddenCol = [];
    	for(i in bodyCol) {	
    		let hidden = bodyCol[i].hidden;
    		if(hidden) hiddenCol.push(i);
    	}
    	return hiddenCol;
    },
    clearBody : function(){
    	document.getElementById("tbl_"+this.id +"_body").getElementsByTagName("tbody")[0].innerHTML = "";
    },
    searchEvent : function(){
    	this.clearBody();
    	let hiddenCol = this.columnSetHiddenCol(this.opts.bodyCol);
    	this.setBody("tbl_"+this.id +"_body", this.opts.bodyCol, this.gridData, hiddenCol);
    },
    refresh : function(){
    	this.getData();
    },
    clickRemove : function(){
    	let _tr = document.getElementById(this.id).getElementsByTagName("tbody")[0].getElementsByTagName("tr");
		for (let i=0;i<_tr.length;i++) {
			if(typeof _tr[i].style.background != undefined) _tr[i].style.background = "";
		}
    },
    getChkData : function(){
    	let _this = this;
    	let chkBody = document.getElementById("tbl_"+this.id+"_body").getElementsByTagName("tbody")[0].getElementsByTagName("input");
    	let i=0;
    	let data = {};
		[].forEach.call(chkBody, function(el ,idx) {
			if(el.checked) data[i++] = _this.gridData[idx];
    	});
		return data;
    }
    
};
/*
let GRID = function () {
	let url = nu1ll;
	this.grid = function (id){
		console.log(id);
	}
    this.data = function (datas) {
         console.log('GGGG');
    };
};
*/
//$.extend( GRID);