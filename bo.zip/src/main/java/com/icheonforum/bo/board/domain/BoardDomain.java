package com.icheonforum.bo.board.domain;


import org.apache.ibatis.type.Alias;

import com.icheonforum.common.common.domain.BaseDomain;

import lombok.Data;

@Data
@Alias("board")
public class BoardDomain extends BaseDomain{
	
    private Integer boardNo;
    private String boardType;
    private String boardTitle;
    private String boardCnts;
    private Long attchNo1;
    private Long attchNo2;
    private Long attchNo3;
}