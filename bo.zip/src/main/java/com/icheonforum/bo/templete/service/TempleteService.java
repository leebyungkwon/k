package com.icheonforum.bo.templete.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.icheonforum.bo.board.domain.BoardDomain;
import com.icheonforum.bo.templete.repository.TempleteRepository;
import com.icheonforum.config.message.ResponseMsg;

@Service
public class TempleteService {

	@Autowired private TempleteRepository templeteRepository;

	@Transactional
	public ResponseMsg templeteSave(BoardDomain board) {
		System.out.println("### no0 : " + board);
		if(null == board.getBoardNo())	templeteRepository.insert(board);
		else							templeteRepository.update(board);
		System.out.println("### no2 : " + board);
		if (null == board.getBoardNo())
			return new ResponseMsg(HttpStatus.BAD_GATEWAY, "COM0002");
		return new ResponseMsg(HttpStatus.OK, "COM0001", board, "����</br>�����Ͽ����ϴ�.");
	}

	@Transactional(readOnly=true)
	public BoardDomain findById(BoardDomain board) {
		//return templeteRepository.findById(board.getBoardNo());
		return null;
	}

	@Transactional
	public HashMap<String, Object> selectTemplete(BoardDomain board) {
		List<BoardDomain> p = templeteRepository.selectTemplete(board);
		int pageCnt = (p.size()>0) ? (int) Math.ceil((double) p.get(0).getTotalPages() / (double) p.get(0).getSize()) : 0; 
		HashMap<String, Object> result = new HashMap<String, Object>();
		result.put("list", p);
		result.put("pageCnt", pageCnt);
		return result;
	}

}
