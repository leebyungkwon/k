package com.icheonforum.bo.templete.controller;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.icheonforum.bo.board.domain.BoardDomain;
import com.icheonforum.bo.templete.service.TempleteService;
import com.icheonforum.common.common.domain.FileDomain;
import com.icheonforum.config.message.ResponseMsg;
import com.icheonforum.config.string.CosntPage;
import com.icheonforum.util.UtilExcel;
import com.icheonforum.util.UtilFile;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping(value="/bo/templete")
public class TempleteController {
	
	@Autowired private TempleteService templeteService;

	@Autowired UtilFile utilFile;
	
	@GetMapping(value="/templetePage")
	public ModelAndView templetePage() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoTempletePage+"/templetePage");
        return mv;
	}
	
	@GetMapping(value="/templete2")
	public ModelAndView templete2() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoTempletePage+"/templete2");
        return mv;
	}
	
	@GetMapping(value="/templete")
	public ModelAndView templete() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoTempletePage+"/templete");
        return mv;
	}
	
	@PostMapping(value="/list")
	public ResponseEntity<ResponseMsg> list(HttpServletRequest request, BoardDomain board){
		Long logId = (Long) request.getAttribute("lid");
		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,null );
    	responseMsg.setData(templeteService.selectTemplete(board));
    	responseMsg.setLogId(logId);
		return new ResponseEntity<ResponseMsg>(responseMsg ,HttpStatus.OK);
	}
	
	@GetMapping(value="/templeteSave")
	public ModelAndView templeteSavePage(BoardDomain board) {
    	ModelAndView mv = new ModelAndView(CosntPage.BoTempletePage+"/templeteSave");
    	String type = "NOTICE";
    	if(null != board.getBoardNo()) {
    		BoardDomain b = templeteService.findById(board);
    		mv.addObject("board", b);
    		type = b.getBoardType();
    	}
		mv.addObject("type", type);
        return mv;
	}
	
	@GetMapping("/p/templeteSave")
    public ModelAndView templeteSavePopup() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoTempletePage+"/p/popTempleteSave");
        return mv;
    }

	@GetMapping("/p/templeteFileSave")
    public ModelAndView templeteFileSave() {
    	ModelAndView mv = new ModelAndView(CosntPage.BoTempletePage+"/p/popTempleteFileSave");
        return mv;
    }
	
	@PostMapping("/templeteSave")
	public ResponseEntity<ResponseMsg> templeteSave(BoardDomain board) {
		ResponseMsg responseMsg = templeteService.templeteSave(board);
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}

	
	@PostMapping("/templeteFileSave")
	public ResponseEntity<ResponseMsg> templeteFileSave(BoardDomain board, @RequestParam("files") MultipartFile[] files, HttpServletRequest request) 
			throws IllegalStateException, IOException {
		
		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,null );
		if(files.length > 0) {
			//List<FileEntity> f = uFile.uploadFiles(files, "test");
			FileDomain entity = new FileDomain();
			Map<String, Object> result = utilFile.setPath("test")
							.setFiles(files)
							.upload();
        }
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
	@PostMapping("/excel")
	public ResponseEntity<ResponseMsg> readExcel(@RequestParam("files") MultipartFile[] files, BoardDomain board) throws IOException { 

		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,null );

		Map<String, Object> ret = utilFile.setPath("test")
				.setFiles(files)
				.setExt("excel")
				.upload();
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(); 
		if((boolean) ret.get("success")) {
			List<FileDomain> file = (List<FileDomain>) ret.get("data");
			for(FileDomain exc : file) {
				String path = Paths.get(exc.getFilePath(), exc.getFileSaveNm()+"."+exc.getFileExt()).toString();
				result = new UtilExcel().upload(path);
			}
			if(file.size() > 0) {
				board.setAttchNo1(file.get(0).getFileAttachId());
				responseMsg = templeteService.templeteSave(board);
			}
		}
	
    	responseMsg.setData(result);
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
	@PostMapping("/img")
	public ResponseEntity<ResponseMsg> img(@RequestParam("files") MultipartFile[] files, BoardDomain board) throws IOException { 

		ResponseMsg responseMsg = new ResponseMsg(HttpStatus.OK ,null );

		Map<String, Object> ret = utilFile.setPath("test")
				.setFiles(files)
				.setExt("image")
				.upload();
		if((boolean) ret.get("success")) {
			List<FileDomain> file = (List<FileDomain>) ret.get("data");
			if(file.size() > 0) {
				board.setAttchNo2(file.get(0).getFileAttachId());
				responseMsg = templeteService.templeteSave(board);
			}
		}
	
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
	}
	
}
