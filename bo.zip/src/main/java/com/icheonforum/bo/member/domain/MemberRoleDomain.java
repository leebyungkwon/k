package com.icheonforum.bo.member.domain;

import org.apache.ibatis.type.Alias;

import com.icheonforum.common.common.domain.BaseDomain;

import lombok.Data;

@Data
@Alias("memberRole")
public class MemberRoleDomain extends BaseDomain{
    private Long roleNo;
    private String roleName;
    MemberDomain member;
}
