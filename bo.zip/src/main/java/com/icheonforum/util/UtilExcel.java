package com.icheonforum.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class UtilExcel {

	public List<Map<String, Object>> upload(String path) {

		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(); 
		Workbook wb = ExcelFileType.getWorkbook(path);
		Sheet sheet = wb.getSheetAt(0);
		
		int numOfCells =sheet.getRow(0).getPhysicalNumberOfCells();
		for(int i=1; i<sheet.getLastRowNum() + 1; i++) {
		    Row row = null;
		    Cell cell = null;
		    
		    String cellName = "";
		    
		    Map<String, Object> map = null;
	        row = sheet.getRow(i);
	        
	        if(row != null) {
	            map = new HashMap<String, Object>();
	            for(int cellIndex = 0; cellIndex < numOfCells; cellIndex++) {
	                cell = row.getCell(cellIndex);
	                cellName = ExcelCellRef.getName(cell, cellIndex);
	                
	                //System.out.println(cellIndex + " :: " + cellName + " :: " + ExcelCellRef.getValue(cell));
	                /*
	                if( !excelReadOption.getOutputColumns().contains(cellName) ) {
	                    continue;
	                }
	                */
	                map.put(cellName, ExcelCellRef.getValue(cell));
	            }
	            result.add(map);
		    }
		}
		return result;
	}

}
