package com.icheonforum.common.common.domain;

import lombok.Builder;
import lombok.Data;

@Data
public class CodeDtlDomain extends BaseDomain{
    private String codeDtlCd;
    private String codeDtlNm;
    private String property01;
    private String property02;
    private String property03;
    private String property04;
    private String property05;
    CodeMstDomain codeMstCd;

    @Builder
    public CodeDtlDomain(String codeDtlCd, String codeDtlNm
    		, String property01, String property02, String property03, String property04, String property05) {
        this.codeDtlCd = codeDtlCd;
        this.codeDtlNm = codeDtlNm;
        this.property01 = property01;
        this.property02 = property02;
        this.property03 = property03;
        this.property04 = property04;
        this.property05 = property05;
    }
}
