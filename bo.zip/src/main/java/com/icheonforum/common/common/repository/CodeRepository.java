package com.icheonforum.common.common.repository;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.common.common.domain.CodeMstDomain;


@Mapper
public interface CodeRepository  {

	CodeMstDomain findByCodeMstCd(String codeMstCd);

}