package com.icheonforum.common.common.repository;

import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.common.common.domain.VersionDomain;


@Mapper
public interface VersionRepository {

	VersionDomain save(VersionDomain versionDomain);
	Optional<VersionDomain> findById(Long verId);
}