package com.icheonforum.common.common.domain;

import lombok.Data;

@Data
public class FileDomain extends BaseDomain{

    private Long fileAttachId;
    private String fileOrgNm;
    private String fileSaveNm;
    private String filePath;
    private String fileExt;
    private String useYn = "Y";
}
