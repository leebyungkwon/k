package com.test_client;

public class StringConst {
	
	public static String SITE_ID = "SVC010";
	public static String KEY = "1234567898765432";
}
