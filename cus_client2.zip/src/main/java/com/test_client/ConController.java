package com.test_client;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConController {

	@RequestMapping("/conn")
	public String conn(String url, String ci, String di) {
		
		return "redirect:index";
	}
}
