package com.test_client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestClient1Application {

	public static void main(String[] args) {
		SpringApplication.run(TestClient1Application.class, args);
	}

}
