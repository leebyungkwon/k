package com.icheonforum.bo.member.repository;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.bo.member.domain.MemberDomain;

@Mapper 
public interface MemberRepository {
	MemberDomain findByEmail(String email);

	MemberDomain save(MemberDomain memberEntity);
}