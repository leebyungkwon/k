package com.icheonforum.bo.member.repository;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.bo.member.domain.MemberRoleDomain;

@Mapper
public interface MemberRoleRepository{

	void save(MemberRoleDomain role);

}