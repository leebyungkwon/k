package com.icheonforum.bo.member.domain;

import com.icheonforum.common.common.domain.BaseDomain;

import lombok.Data;

@Data
public class MemberRoleDomain extends BaseDomain{
    private Long roleNo;
    private String roleName;
    MemberDomain member;
}
