package com.icheonforum.common.common.domain;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
public class CodeMstEntity extends BaseDomain{

    private String codeMstCd;
    private String codeMstNm;
    private String codeMstDesc;
    private String property01;
    private String property02;
    private String property03;
    private String property04;
    private String property05;
    List<CodeDtlDomain> codeDtl;
    
    @Builder
    public CodeMstEntity(String codeMstCd, String codeMstNm, String codeMstDesc
    		, String property01, String property02, String property03, String property04, String property05) {
        this.codeMstCd = codeMstCd;
        this.codeMstNm = codeMstNm;
        this.codeMstDesc = codeMstDesc;
        this.property01 = property01;
        this.property02 = property02;
        this.property03 = property03;
        this.property04 = property04;
        this.property05 = property05;
    }
}
