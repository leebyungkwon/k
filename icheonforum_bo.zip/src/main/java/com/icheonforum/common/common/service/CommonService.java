package com.icheonforum.common.common.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.icheonforum.common.common.domain.CodeDtlDomain;
import com.icheonforum.common.common.domain.CodeMstEntity;
import com.icheonforum.common.common.domain.VersionDomain;
import com.icheonforum.common.common.repository.CodeRepository;
import com.icheonforum.common.common.repository.LogRepository;
import com.icheonforum.common.common.repository.VersionRepository;

@Service
public class CommonService {

	@Autowired private VersionRepository verRepo;
	@Autowired private CodeRepository codeRepo;
	
	@CacheEvict(value = "static", allEntries=true)
	public VersionDomain verSave(VersionDomain versionDomain) {
		return verRepo.save(versionDomain);
	}
	
	@Cacheable(value = "static")
	public Optional<VersionDomain> getVer(VersionDomain versionDomain) {
		return verRepo.findById(versionDomain.getVerId());
	}

	public Object selectCommonCodeList(CodeMstEntity code) {
		CodeMstEntity codeMst = codeRepo.findByCodeMstCd(code.getCodeMstCd());
		List<CodeDtlDomain> codeDet = null;
		if(codeMst != null) {
			codeDet = codeMst.getCodeDtl();
		}
		return codeDet;
	}

}