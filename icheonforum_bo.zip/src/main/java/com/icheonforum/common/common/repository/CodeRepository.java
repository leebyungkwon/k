package com.icheonforum.common.common.repository;

import org.apache.ibatis.annotations.Mapper;

import com.icheonforum.common.common.domain.CodeMstEntity;


@Mapper
public interface CodeRepository  {

	CodeMstEntity findByCodeMstCd(String codeMstCd);

}