package com.icheonforum.common.common.repository;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FileRepository {
}